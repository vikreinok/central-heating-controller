


weight_x=-1:0.0266:1;
weight_y = (0.8* weight_x.^2) + 0.2;

plot(weight_x,weight_y), grid