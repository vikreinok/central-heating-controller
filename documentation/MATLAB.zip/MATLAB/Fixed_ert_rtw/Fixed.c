#include "Fixed.h"
#include "Fixed_private.h"

int16_T error;
int16_T throttle;
int16_T Kp = 25585;
int16_T Ki = 27473;
int16_T Kd = 29580;
D_Work DWork;
RT_MODEL M_;
RT_MODEL *const M = &M_;
void Fixed_step(void)
{
  int16_T FilterCoefficient;
  FilterCoefficient = (int16_T)(int32_T)((int32_T)((int32_T)(int16_T)((int16_T)
    (int32_T)((int32_T)((int32_T)Kd * (int32_T)error) >> 15) -
    DWork.Filter_DSTATE) * 21095L) >> 15);
  throttle = (int16_T)((int16_T)((int16_T)((int16_T)(int32_T)((int32_T)((int32_T)
    Kp * (int32_T)error) >> 15) >> 1) + DWork.Integrator_DSTATE) + (int16_T)
                       (FilterCoefficient >> 1));
  DWork.Integrator_DSTATE += (int16_T)(int32_T)((int32_T)((int32_T)(int16_T)
    (int32_T)((int32_T)((int32_T)Ki * (int32_T)error) >> 15) * 5243L) >> 19);
  DWork.Filter_DSTATE += (int16_T)(int32_T)((int32_T)(5243L * (int32_T)
    FilterCoefficient) >> 15);
}

void Fixed_initialize(void)
{
  rtmSetErrorStatus(M, (NULL));
  throttle = 0;
  (void) memset((void *)&DWork, 0,
                sizeof(D_Work));
  error = 0;
  DWork.Integrator_DSTATE = 9216;
}

void Fixed_terminate(void)
{
}
