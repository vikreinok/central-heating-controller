#ifndef RTW_HEADER_Fixed_types_h_
#define RTW_HEADER_Fixed_types_h_

typedef struct tag_RTM RT_MODEL;

#endif

