#include <stdio.h>
#include "Fixed.h"
#include "rtwtypes.h"

void rt_OneStep(void);
void rt_OneStep(void)
{
  static boolean_T OverrunFlag = 0;
  if (OverrunFlag) {
    rtmSetErrorStatus(M, "Overrun");
    return;
  }

  OverrunFlag = TRUE;
  Fixed_step();
  OverrunFlag = FALSE;
}

int_T main(int_T argc, const char_T *argv[]);
int_T main(int_T argc, const char_T *argv[])
{
  Fixed_initialize();
  printf("Warning: The simulation will run forever. "
         "Generated ERT main won't simulate model step behavior. "
         "To change this behavior select the 'MAT-file logging' option.\n");
  fflush((NULL));
  while (rtmGetErrorStatus(M) == (NULL)) {
  }

  Fixed_terminate();
  return 0;
}
