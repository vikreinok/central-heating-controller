#ifndef RTW_HEADER_Fixed_h_
#define RTW_HEADER_Fixed_h_
#ifndef Fixed_COMMON_INCLUDES_
# define Fixed_COMMON_INCLUDES_
#include <stddef.h>
#include <string.h>
#include "rtwtypes.h"
#endif

#include "Fixed_types.h"

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

typedef struct {
  int16_T Integrator_DSTATE;
  int16_T Filter_DSTATE;
} D_Work;

struct tag_RTM {
  const char_T * volatile errorStatus;
};

extern D_Work DWork;
extern int16_T error;
extern int16_T throttle;
extern int16_T Kp;
extern int16_T Ki;
extern int16_T Kd;
extern void Fixed_initialize(void);
extern void Fixed_step(void);
extern void Fixed_terminate(void);
extern RT_MODEL *const M;

#endif

