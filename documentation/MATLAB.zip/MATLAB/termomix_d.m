% mitttelineaarne klapi karakteristik
% f(u) = Q/Qmax = R^-(1-u) - equal percentage, ekponentsiaalne karakter.
% R= 30...50 -reguleerimise ulatus (rangeability), mittehermeetilisus Qmin ei ole 0

%Coefficients (with 95% confidence bounds):
       p1 =      -1.626;
       p2 =       2.849;  
       p3 =    -0.03899;
       p4 =    -0.02823;


x=0.110:0.01:0.86;
y=p1*x.^3 + p2*x.^2 + p3*x + p4;

plot(y,x), grid



