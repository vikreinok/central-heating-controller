#include "__cf_pid_modulator.h"
#include <math.h>
#include "pid_modulator_acc.h"
#include "pid_modulator_acc_private.h"
#include <stdio.h>
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
void pid_modulator_acc_BINARYSEARCH_real_T ( uint32_T * piLeft , uint32_T *
piRght , real_T u , const real_T * pData , uint32_T iHi ) { * piLeft = 0U ; *
piRght = iHi ; if ( u <= pData [ 0 ] ) { * piRght = 0U ; } else if ( u >=
pData [ iHi ] ) { * piLeft = iHi ; } else { uint32_T i ; while ( ( * piRght -
* piLeft ) > 1U ) { i = ( * piLeft + * piRght ) >> 1 ; if ( u < pData [ i ] )
{ * piRght = i ; } else { * piLeft = i ; } } } } void
pid_modulator_acc_LookUp_real_T_real_T ( real_T * pY , const real_T * pYData
, real_T u , const real_T * pUData , uint32_T iHi ) { uint32_T iLeft ;
uint32_T iRght ; pid_modulator_acc_BINARYSEARCH_real_T ( & ( iLeft ) , & (
iRght ) , u , pUData , iHi ) ; { real_T lambda ; if ( pUData [ iRght ] >
pUData [ iLeft ] ) { real_T num ; real_T den ; den = pUData [ iRght ] ; den =
den - pUData [ iLeft ] ; num = u ; num = num - pUData [ iLeft ] ; lambda =
num / den ; } else { lambda = 0.0 ; } { real_T yLeftCast ; real_T yRghtCast ;
yLeftCast = pYData [ iLeft ] ; yRghtCast = pYData [ iRght ] ; yLeftCast +=
lambda * ( yRghtCast - yLeftCast ) ; ( * pY ) = yLeftCast ; } } } int32_T
div_sus32_floor ( uint32_T numerator , int32_T denominator ) { int32_T
quotient ; uint32_T absDenominator ; uint32_T tempAbsQuotient ; uint32_T
quotientNeedsNegation ; if ( denominator == 0 ) { quotient = MAX_int32_T ; }
else { absDenominator = ( uint32_T ) ( denominator >= 0 ? denominator : -
denominator ) ; quotientNeedsNegation = ( denominator < 0 ) ; tempAbsQuotient
= numerator / absDenominator ; if ( quotientNeedsNegation ) { numerator %=
absDenominator ; if ( numerator > 0 ) { tempAbsQuotient += ( uint32_T ) 1 ; }
} quotient = quotientNeedsNegation ? - ( int32_T ) tempAbsQuotient : (
int32_T ) tempAbsQuotient ; } return quotient ; } int32_T div_sus32_sat (
uint32_T numerator , int32_T denominator ) { int32_T quotient ; uint32_T
tempAbsQuotient ; uint32_T quotientNeedsNegation ; if ( denominator == 0 ) {
quotient = MAX_int32_T ; } else { quotientNeedsNegation = ( denominator < 0 )
; tempAbsQuotient = numerator / ( uint32_T ) ( denominator >= 0 ? denominator
: - denominator ) ; if ( ( ! quotientNeedsNegation ) && ( tempAbsQuotient >=
2147483647U ) ) { quotient = MAX_int32_T ; } else if ( quotientNeedsNegation
&& ( tempAbsQuotient > 2147483647U ) ) { quotient = MIN_int32_T ; } else {
quotient = quotientNeedsNegation ? - ( int32_T ) tempAbsQuotient : ( int32_T
) tempAbsQuotient ; } } return quotient ; } void mul_wide_u32 ( uint32_T in0
, uint32_T in1 , uint32_T * ptrOutBitsHi , uint32_T * ptrOutBitsLo ) {
uint32_T outBitsLo ; uint32_T in0Lo ; uint32_T in0Hi ; uint32_T in1Lo ;
uint32_T in1Hi ; uint32_T productHiLo ; uint32_T productLoHi ; in0Hi = in0 >>
16U ; in0Lo = in0 & 65535U ; in1Hi = in1 >> 16U ; in1Lo = in1 & 65535U ;
productHiLo = in0Hi * in1Lo ; productLoHi = in0Lo * in1Hi ; in0Lo *= in1Lo ;
in1Lo = 0U ; outBitsLo = ( productLoHi << 16U ) + in0Lo ; if ( outBitsLo <
in0Lo ) { in1Lo = 1U ; } in0Lo = outBitsLo ; outBitsLo += productHiLo << 16U
; if ( outBitsLo < in0Lo ) { in1Lo ++ ; } * ptrOutBitsHi = ( ( ( productLoHi
>> 16U ) + ( productHiLo >> 16U ) ) + in0Hi * in1Hi ) + in1Lo ; *
ptrOutBitsLo = outBitsLo ; } uint32_T mul_u32_u32_u32_sr20 ( uint32_T a ,
uint32_T b ) { uint32_T u32_chi ; uint32_T u32_clo ; mul_wide_u32 ( a , b , &
u32_chi , & u32_clo ) ; u32_clo = u32_chi << 12U | u32_clo >> 20U ; return
u32_clo ; } void
pid_modulator_Synthesized_Atomic_Subsystem_For_Alg_Loop_1_Init ( SimStruct *
const S ) { BlockIO_pid_modulator * _rtB ; _rtB = ( ( BlockIO_pid_modulator *
) _ssGetBlockIO ( S ) ) ; ( ( ContinuousStates_pid_modulator * )
ssGetContStates ( S ) ) -> loendur_CSTATE = ( ( Parameters_pid_modulator * )
ssGetDefaultParam ( S ) ) -> P_0 ; } void
pid_modulator_Synthesized_Atomic_Subsystem_For_Alg_Loop_1 ( SimStruct * const
S ) { ssCallAccelRunBlock ( S , 1 , 24 , SS_CALL_MDL_OUTPUTS ) ; } void
pid_modulator_Synthesized_Atomic_Subsystem_For_Alg_Loop_1_Update ( SimStruct
* const S ) { BlockIO_pid_modulator * _rtB ; _rtB = ( ( BlockIO_pid_modulator
* ) _ssGetBlockIO ( S ) ) ; } void
pid_modulator_Synthesized_Atomic_Subsystem_For_Alg_Loop_1_Deriv ( SimStruct *
const S ) { BlockIO_pid_modulator * _rtB ; _rtB = ( ( BlockIO_pid_modulator *
) _ssGetBlockIO ( S ) ) ; { if ( ! ( ( BlockIO_pid_modulator * )
_ssGetBlockIO ( S ) ) -> B_0_0_0 ) { ( ( StateDerivatives_pid_modulator * )
ssGetdX ( S ) ) -> loendur_CSTATE = ( ( BlockIO_pid_modulator * )
_ssGetBlockIO ( S ) ) -> B_1_93_0 ; } else { ( (
StateDerivatives_pid_modulator * ) ssGetdX ( S ) ) -> loendur_CSTATE = 0.0 ;
} } } void pid_modulator_Synthesized_Atomic_Subsystem_For_Alg_Loop_1_ZC (
SimStruct * const S ) { BlockIO_pid_modulator * _rtB ; _rtB = ( (
BlockIO_pid_modulator * ) _ssGetBlockIO ( S ) ) ; ( (
ZCSignalValues_pid_modulator * ) ssGetSolverZcSignalVector ( S ) ) ->
RelationalOperator2_RelopInput_ZC = _rtB -> B_0_1_0 - _rtB -> B_1_23_0 ; }
static void mdlOutputs ( SimStruct * S , int_T tid ) { real_T B_1_30_0 ;
real_T B_1_94_0 ; real_T B_1_67_0 ; real_T B_1_46_0 ; real_T B_1_58_0 ;
uint16_T B_1_89_0 ; boolean_T B_1_16_0 ; uint16_T B_1_78_0 ; int32_T tmp ;
real_T u ; BlockIO_pid_modulator * _rtB ; Parameters_pid_modulator * _rtP ;
D_Work_pid_modulator * _rtDW ; _rtDW = ( ( D_Work_pid_modulator * )
ssGetRootDWork ( S ) ) ; _rtP = ( ( Parameters_pid_modulator * )
ssGetDefaultParam ( S ) ) ; _rtB = ( ( BlockIO_pid_modulator * )
_ssGetBlockIO ( S ) ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { B_1_46_0 = _rtP
-> P_1 ; _rtB -> B_1_1_0 = _rtP -> P_2 ; } ( ( BlockIO_pid_modulator * )
_ssGetBlockIO ( S ) ) -> B_1_2_0 = ( ( ContinuousStates_pid_modulator * )
ssGetContStates ( S ) ) -> Integrator_CSTATE ; _rtB -> B_1_3_0 = _rtB ->
B_1_1_0 - _rtB -> B_1_2_0 ; if ( ssIsSampleHit ( S , 2 , 0 ) ) { u =
muDoubleScalarFloor ( _rtB -> B_1_3_0 * 512.0 ) ; if ( muDoubleScalarIsNaN (
u ) || muDoubleScalarIsInf ( u ) ) { u = 0.0 ; } else { u = muDoubleScalarRem
( u , 65536.0 ) ; } u = ( real_T ) ( u < 0.0 ? ( int16_T ) - ( int16_T ) (
uint16_T ) - u : ( int16_T ) ( uint16_T ) u ) * 0.001953125 * _rtP -> P_4 ;
if ( u >= _rtP -> P_5 ) { _rtB -> B_1_7_0 = _rtP -> P_5 ; } else if ( u <=
_rtP -> P_6 ) { _rtB -> B_1_7_0 = _rtP -> P_6 ; } else { _rtB -> B_1_7_0 = u
; } } if ( ssIsSampleHit ( S , 1 , 0 ) ) { if ( ! ( _rtB -> B_1_7_0 > _rtP ->
P_8 ) ) { B_1_46_0 = _rtP -> P_7 ; } B_1_89_0 = _rtP -> P_56 ; } if (
ssIsSampleHit ( S , 2 , 0 ) ) { u = muDoubleScalarFloor ( muDoubleScalarAbs (
_rtB -> B_1_7_0 ) ) ; if ( muDoubleScalarIsNaN ( u ) || muDoubleScalarIsInf (
u ) ) { _rtB -> B_1_12_0 = 0 ; } else { _rtB -> B_1_12_0 = ( int16_T ) (
uint16_T ) muDoubleScalarRem ( u , 65536.0 ) ; } } if ( ssIsSampleHit ( S , 1
, 0 ) ) { if ( _rtB -> B_1_12_0 >= _rtP -> P_52 ) { _rtB -> B_1_14_0 = _rtB
-> B_1_12_0 ; } else { _rtB -> B_1_14_0 = _rtP -> P_51 ; } _rtB -> B_1_15_0 =
_rtP -> P_53 ; B_1_16_0 = ( _rtB -> B_1_14_0 < _rtB -> B_1_15_0 ) ; if ( !
B_1_16_0 ) { B_1_89_0 = ( uint16_T ) div_sus32_floor ( mul_u32_u32_u32_sr20 (
_rtP -> P_50 , ( uint32_T ) _rtB -> B_1_14_0 ) , ( int32_T ) _rtP -> P_54 ) ;
} _rtB -> B_1_22_0 = ( real_T ) B_1_89_0 ; _rtB -> B_1_23_0 = _rtDW ->
Memory4_PreviousInput ; }
pid_modulator_Synthesized_Atomic_Subsystem_For_Alg_Loop_1 ( ( SimStruct *
const ) S ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { if ( ssIsMajorTimeStep ( S
) ) { _rtDW -> RelationalOperator_Mode = ( _rtB -> B_1_22_0 >= _rtB ->
B_0_1_0 ) ; } if ( _rtDW -> RelationalOperator_Mode ) { _rtB -> B_1_27_0 =
B_1_46_0 ; } else { _rtB -> B_1_27_0 = _rtP -> P_10 ; } _rtB -> B_1_28_0 =
_rtP -> P_11 * _rtB -> B_1_27_0 ; _rtB -> B_1_29_0 = _rtP -> P_12 ; } if (
ssIsMajorTimeStep ( S ) ) { if ( ( ( ContinuousStates_pid_modulator * )
ssGetContStates ( S ) ) -> Integrator1_CSTATE >= _rtP -> P_14 ) { ( (
ContinuousStates_pid_modulator * ) ssGetContStates ( S ) ) ->
Integrator1_CSTATE = _rtP -> P_14 ; } else if ( ( (
ContinuousStates_pid_modulator * ) ssGetContStates ( S ) ) ->
Integrator1_CSTATE <= _rtP -> P_15 ) { ( ( ContinuousStates_pid_modulator * )
ssGetContStates ( S ) ) -> Integrator1_CSTATE = _rtP -> P_15 ; } } B_1_30_0 =
( ( ContinuousStates_pid_modulator * ) ssGetContStates ( S ) ) ->
Integrator1_CSTATE ; _rtB -> B_1_31_0 = _rtP -> P_16 [ 0 ] ; _rtB -> B_1_31_0
= _rtB -> B_1_31_0 * B_1_30_0 + _rtP -> P_16 [ 1 ] ; _rtB -> B_1_31_0 = _rtB
-> B_1_31_0 * B_1_30_0 + _rtP -> P_16 [ 2 ] ; _rtB -> B_1_31_0 = _rtB ->
B_1_31_0 * B_1_30_0 + _rtP -> P_16 [ 3 ] ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> Switch_Mode = ( _rtB -> B_1_31_0 >= _rtP -> P_17 ) ; } if ( _rtDW ->
Switch_Mode ) { _rtB -> B_1_32_0 = _rtB -> B_1_29_0 ; } else { _rtB ->
B_1_32_0 = _rtB -> B_1_31_0 ; } if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB ->
B_1_33_0 = _rtP -> P_18 ; } if ( ssIsMajorTimeStep ( S ) ) { _rtDW ->
Switch1_Mode = ( _rtB -> B_1_31_0 >= _rtP -> P_19 ) ; } if ( ssIsSampleHit (
S , 1 , 0 ) ) { B_1_58_0 = _rtP -> P_23 * _rtP -> P_22 ; B_1_46_0 = _rtP ->
P_25 / _rtP -> P_26 ; if ( _rtP -> P_20 < 0.0 ) { u = - muDoubleScalarSqrt (
muDoubleScalarAbs ( _rtP -> P_20 ) ) ; } else { u = muDoubleScalarSqrt ( _rtP
-> P_20 ) ; } if ( B_1_46_0 < 0.0 ) { B_1_46_0 = - muDoubleScalarSqrt (
muDoubleScalarAbs ( B_1_46_0 ) ) ; } else { B_1_46_0 = muDoubleScalarSqrt (
B_1_46_0 ) ; } _rtB -> B_1_49_0 = B_1_58_0 * B_1_58_0 * _rtP -> P_24 *
B_1_46_0 * _rtP -> P_27 * ( u / _rtP -> P_21 ) ; } if ( _rtDW -> Switch1_Mode
) { u = _rtB -> B_1_32_0 ; } else { u = _rtB -> B_1_33_0 ; } B_1_46_0 = u *
_rtB -> B_1_49_0 ; B_1_58_0 = _rtP -> P_28 * B_1_46_0 ; if ( ssIsSampleHit (
S , 1 , 0 ) ) { _rtB -> B_1_52_0 = _rtP -> P_29 ; } if ( ( B_1_58_0 < 0.0 )
&& ( _rtB -> B_1_52_0 > muDoubleScalarFloor ( _rtB -> B_1_52_0 ) ) ) {
B_1_58_0 = - muDoubleScalarPower ( - B_1_58_0 , _rtB -> B_1_52_0 ) ; } else {
B_1_58_0 = muDoubleScalarPower ( B_1_58_0 , _rtB -> B_1_52_0 ) ; } B_1_58_0
*= _rtP -> P_30 ; if ( B_1_58_0 < 0.0 ) { B_1_58_0 = - muDoubleScalarSqrt (
muDoubleScalarAbs ( B_1_58_0 ) ) ; } else { B_1_58_0 = muDoubleScalarSqrt (
B_1_58_0 ) ; } _rtB -> B_1_56_0 = B_1_46_0 * B_1_58_0 ; if ( ssIsSampleHit (
S , 1 , 0 ) ) { B_1_46_0 = _rtP -> P_31 * _rtB -> B_1_49_0 ; if ( ( B_1_46_0
< 0.0 ) && ( _rtP -> P_32 > muDoubleScalarFloor ( _rtP -> P_32 ) ) ) {
B_1_46_0 = - muDoubleScalarPower ( - B_1_46_0 , _rtP -> P_32 ) ; } else {
B_1_46_0 = muDoubleScalarPower ( B_1_46_0 , _rtP -> P_32 ) ; } B_1_46_0 *=
_rtP -> P_33 ; if ( B_1_46_0 < 0.0 ) { B_1_46_0 = - muDoubleScalarSqrt (
muDoubleScalarAbs ( B_1_46_0 ) ) ; } else { B_1_46_0 = muDoubleScalarSqrt (
B_1_46_0 ) ; } _rtB -> B_1_62_0 = _rtB -> B_1_49_0 * B_1_46_0 ; } B_1_46_0 =
_rtB -> B_1_56_0 / _rtB -> B_1_62_0 ; ( ( BlockIO_pid_modulator * )
_ssGetBlockIO ( S ) ) -> B_1_64_0 = ( ( ContinuousStates_pid_modulator * )
ssGetContStates ( S ) ) -> Integrator1_CSTATE_l ; if ( ssIsSampleHit ( S , 3
, 0 ) ) { B_1_78_0 = _rtDW -> Output_DSTATE ; B_1_67_0 = ( real_T ) _rtDW ->
Output_DSTATE ; pid_modulator_acc_LookUp_real_T_real_T ( & ( ( (
BlockIO_pid_modulator * ) _ssGetBlockIO ( S ) ) -> B_1_68_0 ) , _rtP -> P_36
, B_1_67_0 , _rtP -> P_35 , 5U ) ; } _rtB -> B_1_71_0 = ( _rtB -> B_1_68_0 -
_rtB -> B_1_64_0 ) * B_1_46_0 + _rtB -> B_1_64_0 ; ssCallAccelRunBlock ( S ,
1 , 72 , SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 1 , 73 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_1_75_0 = ( _rtB -> B_1_71_0 - _rtB ->
B_1_2_0 ) * _rtP -> P_37 ; B_1_46_0 = _rtP -> P_38 * _rtB -> B_1_56_0 ; if (
ssIsSampleHit ( S , 3 , 0 ) ) { B_1_78_0 = ( uint16_T ) ( ( uint32_T )
B_1_78_0 + ( uint32_T ) _rtP -> P_58 ) ; if ( B_1_78_0 > _rtP -> P_60 ) {
_rtB -> B_1_80_0 = _rtP -> P_59 ; } else { _rtB -> B_1_80_0 = B_1_78_0 ; } }
if ( ssIsSampleHit ( S , 1 , 0 ) ) { ssCallAccelRunBlock ( S , 1 , 81 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_1_83_0 = ( int16_T ) ( _rtP -> P_62 * (
int32_T ) B_1_16_0 >> 1 ) ; ssCallAccelRunBlock ( S , 1 , 84 ,
SS_CALL_MDL_OUTPUTS ) ; if ( _rtB -> B_0_0_0 ) { _rtB -> B_1_91_0 = _rtDW ->
Memory2_PreviousInput ; } else if ( B_1_16_0 ) { tmp = div_sus32_sat ( (
uint32_T ) ( _rtP -> P_63 * _rtP -> P_55 >> 1 ) , ( int32_T ) _rtB ->
B_1_14_0 ) ; if ( tmp < 0 ) { tmp = 0 ; } else { if ( tmp > 65535 ) { tmp =
65535 ; } } _rtB -> B_1_91_0 = ( real_T ) tmp ; } else { _rtB -> B_1_91_0 = (
real_T ) _rtP -> P_61 ; } } ssCallAccelRunBlock ( S , 1 , 92 ,
SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> B_1_93_0
= _rtP -> P_40 ; } B_1_94_0 = ( ( ContinuousStates_pid_modulator * )
ssGetContStates ( S ) ) -> Integrator1_CSTATE_f ; if ( ssIsSampleHit ( S , 1
, 0 ) ) { _rtB -> B_1_95_0 = _rtP -> P_42 ; } if ( ssIsSampleHit ( S , 1 , 0
) ) { if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> Tk_MODE = ( int_T ) (
ssGetTaskTime ( S , 1 ) >= _rtP -> P_44 ) ; } if ( _rtDW -> Tk_MODE == 1 ) {
_rtB -> B_1_99_0 = _rtP -> P_46 ; } else { _rtB -> B_1_99_0 = _rtP -> P_45 ;
} } _rtB -> B_1_103_0 = ( ( _rtB -> B_1_71_0 - _rtB -> B_1_64_0 ) * B_1_46_0
* _rtP -> P_43 - ( _rtB -> B_1_64_0 - _rtB -> B_1_99_0 ) * _rtP -> P_47 ) *
_rtP -> P_48 ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> B_1_104_0 = _rtP
-> P_49 * _rtB -> B_1_27_0 ; } ssCallAccelRunBlock ( S , 1 , 105 ,
SS_CALL_MDL_OUTPUTS ) ; UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { BlockIO_pid_modulator *
_rtB ; Parameters_pid_modulator * _rtP ; D_Work_pid_modulator * _rtDW ; _rtDW
= ( ( D_Work_pid_modulator * ) ssGetRootDWork ( S ) ) ; _rtP = ( (
Parameters_pid_modulator * ) ssGetDefaultParam ( S ) ) ; _rtB = ( (
BlockIO_pid_modulator * ) _ssGetBlockIO ( S ) ) ; if ( ssIsSampleHit ( S , 1
, 0 ) ) { _rtDW -> Memory4_PreviousInput = _rtB -> B_1_91_0 ; }
pid_modulator_Synthesized_Atomic_Subsystem_For_Alg_Loop_1_Update ( (
SimStruct * const ) S ) ; { enum { INTG_NORMAL , INTG_LEAVING_UPPER_SAT ,
INTG_LEAVING_LOWER_SAT , INTG_UPPER_SAT , INTG_LOWER_SAT } ; if ( ( (
ContinuousStates_pid_modulator * ) ssGetContStates ( S ) ) ->
Integrator1_CSTATE == _rtP -> P_14 ) { switch ( _rtDW -> Integrator1_MODE ) {
case INTG_UPPER_SAT : if ( ( ( BlockIO_pid_modulator * ) _ssGetBlockIO ( S )
) -> B_1_104_0 < 0.0 ) { ssSetSolverNeedsReset ( S ) ; _rtDW ->
Integrator1_MODE = INTG_LEAVING_UPPER_SAT ; } break ; case
INTG_LEAVING_UPPER_SAT : if ( ( ( BlockIO_pid_modulator * ) _ssGetBlockIO ( S
) ) -> B_1_104_0 >= 0.0 ) { _rtDW -> Integrator1_MODE = INTG_UPPER_SAT ;
ssSetSolverNeedsReset ( S ) ; } break ; default : ssSetSolverNeedsReset ( S )
; if ( ( ( BlockIO_pid_modulator * ) _ssGetBlockIO ( S ) ) -> B_1_104_0 < 0.0
) { _rtDW -> Integrator1_MODE = INTG_LEAVING_UPPER_SAT ; } else { _rtDW ->
Integrator1_MODE = INTG_UPPER_SAT ; } break ; } } else if ( ( (
ContinuousStates_pid_modulator * ) ssGetContStates ( S ) ) ->
Integrator1_CSTATE == _rtP -> P_15 ) { switch ( _rtDW -> Integrator1_MODE ) {
case INTG_LOWER_SAT : if ( ( ( BlockIO_pid_modulator * ) _ssGetBlockIO ( S )
) -> B_1_104_0 > 0.0 ) { ssSetSolverNeedsReset ( S ) ; _rtDW ->
Integrator1_MODE = INTG_LEAVING_LOWER_SAT ; } break ; case
INTG_LEAVING_LOWER_SAT : if ( ( ( BlockIO_pid_modulator * ) _ssGetBlockIO ( S
) ) -> B_1_104_0 <= 0.0 ) { _rtDW -> Integrator1_MODE = INTG_LOWER_SAT ;
ssSetSolverNeedsReset ( S ) ; } break ; default : ssSetSolverNeedsReset ( S )
; if ( ( ( BlockIO_pid_modulator * ) _ssGetBlockIO ( S ) ) -> B_1_104_0 > 0.0
) { _rtDW -> Integrator1_MODE = INTG_LEAVING_LOWER_SAT ; } else { _rtDW ->
Integrator1_MODE = INTG_LOWER_SAT ; } break ; } } else { _rtDW ->
Integrator1_MODE = INTG_NORMAL ; } } if ( ssIsSampleHit ( S , 3 , 0 ) ) {
_rtDW -> Output_DSTATE = _rtB -> B_1_80_0 ; } if ( ssIsSampleHit ( S , 1 , 0
) ) { _rtDW -> Memory2_PreviousInput = _rtB -> B_1_91_0 ; } UNUSED_PARAMETER
( tid ) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { BlockIO_pid_modulator * _rtB ;
Parameters_pid_modulator * _rtP ; _rtP = ( ( Parameters_pid_modulator * )
ssGetDefaultParam ( S ) ) ; _rtB = ( ( BlockIO_pid_modulator * )
_ssGetBlockIO ( S ) ) ; { ( ( StateDerivatives_pid_modulator * ) ssGetdX ( S
) ) -> Integrator_CSTATE = ( ( BlockIO_pid_modulator * ) _ssGetBlockIO ( S )
) -> B_1_75_0 ; }
pid_modulator_Synthesized_Atomic_Subsystem_For_Alg_Loop_1_Deriv ( ( SimStruct
* const ) S ) ; { enum { INTG_NORMAL , INTG_LEAVING_UPPER_SAT ,
INTG_LEAVING_LOWER_SAT , INTG_UPPER_SAT , INTG_LOWER_SAT } ; if ( ( ( (
D_Work_pid_modulator * ) ssGetRootDWork ( S ) ) -> Integrator1_MODE !=
INTG_UPPER_SAT ) && ( ( ( D_Work_pid_modulator * ) ssGetRootDWork ( S ) ) ->
Integrator1_MODE != INTG_LOWER_SAT ) ) { ( ( StateDerivatives_pid_modulator *
) ssGetdX ( S ) ) -> Integrator1_CSTATE = ( ( BlockIO_pid_modulator * )
_ssGetBlockIO ( S ) ) -> B_1_104_0 ; ( ( StateDisabled_pid_modulator * )
ssGetContStateDisabled ( S ) ) -> Integrator1_CSTATE = FALSE ; } else { ( (
StateDerivatives_pid_modulator * ) ssGetdX ( S ) ) -> Integrator1_CSTATE =
0.0 ; if ( ( ( ( D_Work_pid_modulator * ) ssGetRootDWork ( S ) ) ->
Integrator1_MODE == INTG_UPPER_SAT ) || ( ( ( D_Work_pid_modulator * )
ssGetRootDWork ( S ) ) -> Integrator1_MODE == INTG_LOWER_SAT ) ) { ( (
StateDisabled_pid_modulator * ) ssGetContStateDisabled ( S ) ) ->
Integrator1_CSTATE = TRUE ; } } } { ( ( StateDerivatives_pid_modulator * )
ssGetdX ( S ) ) -> Integrator1_CSTATE_l = ( ( BlockIO_pid_modulator * )
_ssGetBlockIO ( S ) ) -> B_1_103_0 ; } { ( ( StateDerivatives_pid_modulator *
) ssGetdX ( S ) ) -> Integrator1_CSTATE_f = ( ( BlockIO_pid_modulator * )
_ssGetBlockIO ( S ) ) -> B_1_95_0 ; } }
#define MDL_ZERO_CROSSINGS
static void mdlZeroCrossings ( SimStruct * S ) { BlockIO_pid_modulator * _rtB
; Parameters_pid_modulator * _rtP ; ZCSignalValues_pid_modulator * _rtZCSV ;
_rtZCSV = ( ( ZCSignalValues_pid_modulator * ) ssGetSolverZcSignalVector ( S
) ) ; _rtP = ( ( Parameters_pid_modulator * ) ssGetDefaultParam ( S ) ) ;
_rtB = ( ( BlockIO_pid_modulator * ) _ssGetBlockIO ( S ) ) ;
pid_modulator_Synthesized_Atomic_Subsystem_For_Alg_Loop_1_ZC ( ( SimStruct *
const ) S ) ; _rtZCSV -> RelationalOperator_RelopInput_ZC = _rtB -> B_1_22_0
- _rtB -> B_0_1_0 ; { enum { INTG_NORMAL , INTG_LEAVING_UPPER_SAT ,
INTG_LEAVING_LOWER_SAT , INTG_UPPER_SAT , INTG_LOWER_SAT } ; if ( ( (
D_Work_pid_modulator * ) ssGetRootDWork ( S ) ) -> Integrator1_MODE ==
INTG_LEAVING_UPPER_SAT && ( ( ContinuousStates_pid_modulator * )
ssGetContStates ( S ) ) -> Integrator1_CSTATE >= _rtP -> P_14 ) { ( (
ZCSignalValues_pid_modulator * ) ssGetSolverZcSignalVector ( S ) ) ->
Integrator1_IntgUpLimit_ZC = 0.0 ; } else { ( ( ZCSignalValues_pid_modulator
* ) ssGetSolverZcSignalVector ( S ) ) -> Integrator1_IntgUpLimit_ZC = ( (
ContinuousStates_pid_modulator * ) ssGetContStates ( S ) ) ->
Integrator1_CSTATE - _rtP -> P_14 ; } if ( ( ( D_Work_pid_modulator * )
ssGetRootDWork ( S ) ) -> Integrator1_MODE == INTG_LEAVING_LOWER_SAT && ( (
ContinuousStates_pid_modulator * ) ssGetContStates ( S ) ) ->
Integrator1_CSTATE <= _rtP -> P_15 ) { ( ( ZCSignalValues_pid_modulator * )
ssGetSolverZcSignalVector ( S ) ) -> Integrator1_IntgLoLimit_ZC = 0.0 ; }
else { ( ( ZCSignalValues_pid_modulator * ) ssGetSolverZcSignalVector ( S ) )
-> Integrator1_IntgLoLimit_ZC = ( ( ContinuousStates_pid_modulator * )
ssGetContStates ( S ) ) -> Integrator1_CSTATE - _rtP -> P_15 ; } } _rtZCSV ->
Switch_SwitchCond_ZC = _rtB -> B_1_31_0 - _rtP -> P_17 ; _rtZCSV ->
Switch1_SwitchCond_ZC = _rtB -> B_1_31_0 - _rtP -> P_19 ; _rtZCSV ->
Tk_StepTime_ZC = ssGetT ( S ) - _rtP -> P_44 ; } static void
mdlInitializeSizes ( SimStruct * S ) { ssSetChecksumVal ( S , 0 , 813936359U
) ; ssSetChecksumVal ( S , 1 , 4291534023U ) ; ssSetChecksumVal ( S , 2 ,
4150197889U ) ; ssSetChecksumVal ( S , 3 , 2772992016U ) ; { mxArray *
slVerStructMat = NULL ; mxArray * slStrMat = mxCreateString ( "simulink" ) ;
char slVerChar [ 10 ] ; int status = mexCallMATLAB ( 1 , & slVerStructMat , 1
, & slStrMat , "ver" ) ; if ( status == 0 ) { mxArray * slVerMat = mxGetField
( slVerStructMat , 0 , "Version" ) ; if ( slVerMat == NULL ) { status = 1 ; }
else { status = mxGetString ( slVerMat , slVerChar , 10 ) ; } }
mxDestroyArray ( slStrMat ) ; mxDestroyArray ( slVerStructMat ) ; if ( (
status == 1 ) || ( strcmp ( slVerChar , "8.0" ) != 0 ) ) { return ; } }
ssSetOptions ( S , SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork (
S ) != sizeof ( D_Work_pid_modulator ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( BlockIO_pid_modulator ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
Parameters_pid_modulator ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetDefaultParam ( S , (
real_T * ) & pid_modulator_rtDefaultParameters ) ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { } static void mdlTerminate (
SimStruct * S ) { }
#include "simulink.c"
