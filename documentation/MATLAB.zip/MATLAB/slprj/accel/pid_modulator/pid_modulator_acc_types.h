#include "__cf_pid_modulator.h"
#ifndef RTW_HEADER_pid_modulator_acc_types_h_
#define RTW_HEADER_pid_modulator_acc_types_h_
#include "rtwtypes.h"
typedef struct Parameters_pid_modulator_ Parameters_pid_modulator ;
#endif
