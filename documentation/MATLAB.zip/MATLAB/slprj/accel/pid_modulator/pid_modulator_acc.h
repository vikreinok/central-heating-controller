#include "__cf_pid_modulator.h"
#ifndef RTW_HEADER_pid_modulator_acc_h_
#define RTW_HEADER_pid_modulator_acc_h_
#ifndef pid_modulator_acc_COMMON_INCLUDES_
#define pid_modulator_acc_COMMON_INCLUDES_
#include <stdlib.h>
#include <stddef.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "mwmathutil.h"
#include "rt_defines.h"
#endif
#include "pid_modulator_acc_types.h"
typedef struct { real_T B_1_1_0 ; real_T B_1_3_0 ; real_T B_1_7_0 ; real_T
B_1_22_0 ; real_T B_1_23_0 ; real_T B_1_28_0 ; real_T B_1_29_0 ; real_T
B_1_31_0 ; real_T B_1_32_0 ; real_T B_1_33_0 ; real_T B_1_49_0 ; real_T
B_1_52_0 ; real_T B_1_62_0 ; real_T B_1_68_0 ; real_T B_1_75_0 ; real_T
B_1_91_0 ; real_T B_1_93_0 ; real_T B_1_95_0 ; real_T B_1_99_0 ; real_T
B_1_103_0 ; real_T B_1_104_0 ; real_T B_0_1_0 ; real_T B_1_2_0 ; real_T
B_1_27_0 ; real_T B_1_56_0 ; real_T B_1_64_0 ; real_T B_1_71_0 ; int16_T
B_1_12_0 ; int16_T B_1_14_0 ; int16_T B_1_15_0 ; int16_T B_1_83_0 ; uint16_T
B_1_80_0 ; boolean_T B_0_0_0 ; char pad_B_0_0_0 [ 5 ] ; }
BlockIO_pid_modulator ; typedef struct { real_T Memory4_PreviousInput ;
real_T Memory2_PreviousInput ; void *
Synthesized_Atomic_Subsystem_For_Alg_Loop_1_AlgLoopData ; struct { void *
LoggedData ; } Scope1_PWORK ; struct { void * LoggedData ; } Scope2_PWORK ;
struct { void * LoggedData ; } Scope5_PWORK ; struct { void * LoggedData ; }
mberllitus_PWORK ; struct { void * LoggedData ; } mberllitus1_PWORK ; struct
{ void * LoggedData ; } KvsKvscope_PWORK ; int_T Integrator1_MODE ; int_T
Tk_MODE ; uint16_T Output_DSTATE ; int8_T MathFunction3_DWORK1 ; int8_T
MathFunction1_DWORK1 ; int8_T MathFunction1_DWORK1_i ; int8_T
MathFunction_DWORK1 ; boolean_T RelationalOperator_Mode ; boolean_T
Switch_Mode ; boolean_T Switch1_Mode ; boolean_T RelationalOperator2_Mode ;
char pad_RelationalOperator2_Mode [ 6 ] ; } D_Work_pid_modulator ; typedef
struct { real_T Integrator_CSTATE ; real_T Integrator1_CSTATE ; real_T
Integrator1_CSTATE_l ; real_T Integrator1_CSTATE_f ; real_T loendur_CSTATE ;
} ContinuousStates_pid_modulator ; typedef struct { real_T Integrator_CSTATE
; real_T Integrator1_CSTATE ; real_T Integrator1_CSTATE_l ; real_T
Integrator1_CSTATE_f ; real_T loendur_CSTATE ; }
StateDerivatives_pid_modulator ; typedef struct { boolean_T Integrator_CSTATE
; boolean_T Integrator1_CSTATE ; boolean_T Integrator1_CSTATE_l ; boolean_T
Integrator1_CSTATE_f ; boolean_T loendur_CSTATE ; }
StateDisabled_pid_modulator ; typedef struct { real_T Integrator_CSTATE ;
real_T Integrator1_CSTATE ; real_T Integrator1_CSTATE_l ; real_T
Integrator1_CSTATE_f ; real_T loendur_CSTATE ; } CStateAbsTol_pid_modulator ;
typedef struct { real_T RelationalOperator_RelopInput_ZC ; real_T
Integrator1_IntgUpLimit_ZC ; real_T Integrator1_IntgLoLimit_ZC ; real_T
Switch_SwitchCond_ZC ; real_T Switch1_SwitchCond_ZC ; real_T Tk_StepTime_ZC ;
real_T RelationalOperator2_RelopInput_ZC ; real_T loendur_Reset_ZC ; }
ZCSignalValues_pid_modulator ; typedef struct { ZCSigState
RelationalOperator_RelopInput_ZCE ; ZCSigState Integrator1_IntgUpLimit_ZCE ;
ZCSigState Integrator1_IntgLoLimit_ZCE ; ZCSigState Switch_SwitchCond_ZCE ;
ZCSigState Switch1_SwitchCond_ZCE ; ZCSigState Tk_StepTime_ZCE ; ZCSigState
RelationalOperator2_RelopInput_ZCE ; ZCSigState loendur_Reset_ZCE ; }
PrevZCSigStates_pid_modulator ; struct Parameters_pid_modulator_ { real_T P_0
; real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6
; real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11 ; real_T
P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ; real_T P_16 [ 4 ] ; real_T
P_17 ; real_T P_18 ; real_T P_19 ; real_T P_20 ; real_T P_21 ; real_T P_22 ;
real_T P_23 ; real_T P_24 ; real_T P_25 ; real_T P_26 ; real_T P_27 ; real_T
P_28 ; real_T P_29 ; real_T P_30 ; real_T P_31 ; real_T P_32 ; real_T P_33 ;
real_T P_34 ; real_T P_35 [ 6 ] ; real_T P_36 [ 6 ] ; real_T P_37 ; real_T
P_38 ; real_T P_39 ; real_T P_40 ; real_T P_41 ; real_T P_42 ; real_T P_43 ;
real_T P_44 ; real_T P_45 ; real_T P_46 ; real_T P_47 ; real_T P_48 ; real_T
P_49 ; uint32_T P_50 ; int16_T P_51 ; int16_T P_52 ; int16_T P_53 ; int16_T
P_54 ; int16_T P_55 ; uint16_T P_56 ; uint16_T P_57 ; uint16_T P_58 ;
uint16_T P_59 ; uint16_T P_60 ; uint16_T P_61 ; int16_T P_62 ; int16_T P_63 ;
char pad_P_63 [ 2 ] ; } ; extern Parameters_pid_modulator
pid_modulator_rtDefaultParameters ;
#endif
