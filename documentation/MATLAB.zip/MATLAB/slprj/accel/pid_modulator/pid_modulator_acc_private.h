#include "__cf_pid_modulator.h"
#ifndef RTW_HEADER_pid_modulator_acc_private_h_
#define RTW_HEADER_pid_modulator_acc_private_h_
#include "rtwtypes.h"
#ifndef RTW_COMMON_DEFINES_
#define RTW_COMMON_DEFINES_
#define rt_VALIDATE_MEMORY(S, ptr)   if(!(ptr)) {\
  ssSetErrorStatus(S, RT_MEMORY_ALLOCATION_ERROR);\
  }
#if !defined(_WIN32)
#define rt_FREE(ptr)   if((ptr) != (NULL)) {\
  free((ptr));\
  (ptr) = (NULL);\
  }
#else
#define rt_FREE(ptr)   if((ptr) != (NULL)) {\
  free((void *)(ptr));\
  (ptr) = (NULL);\
  }
#endif
#endif
#ifndef UCHAR_MAX
#include <limits.h>
#endif
#if ( UCHAR_MAX != (0xFFU) ) || ( SCHAR_MAX != (0x7F) )
#error "Code was generated for compiler with different sized uchar/char. Consider adjusting Emulation Hardware word size settings on the Hardware Implementation pane to match your compiler word sizes as defined in the compiler's limits.h header file. Alternatively, you can select 'None' for Emulation Hardware and select the 'Enable portable word sizes' option for ERT based targets, which will disable the preprocessor word size checks."
#endif
#if ( USHRT_MAX != (0xFFFFU) ) || ( SHRT_MAX != (0x7FFF) )
#error "Code was generated for compiler with different sized ushort/short. Consider adjusting Emulation Hardware word size settings on the Hardware Implementation pane to match your compiler word sizes as defined in the compilers limits.h header file. Alternatively, you can select 'None' for Emulation Hardware and select the 'Enable portable word sizes' option for ERT based targets, this will disable the preprocessor word size checks."
#endif
#if ( UINT_MAX != (0xFFFFFFFFU) ) || ( INT_MAX != (0x7FFFFFFF) )
#error "Code was generated for compiler with different sized uint/int. Consider adjusting Emulation Hardware word size settings on the Hardware Implementation pane to match your compiler word sizes as defined in the compilers limits.h header file. Alternatively, you can select 'None' for Emulation Hardware and select the 'Enable portable word sizes' option for ERT based targets, this will disable the preprocessor word size checks."
#endif
#if ( ULONG_MAX != (0xFFFFFFFFU) ) || ( LONG_MAX != (0x7FFFFFFF) )
#error "Code was generated for compiler with different sized ulong/long. Consider adjusting Emulation Hardware word size settings on the Hardware Implementation pane to match your compiler word sizes as defined in the compilers limits.h header file. Alternatively, you can select 'None' for Emulation Hardware and select the 'Enable portable word sizes' option for ERT based targets, this will disable the preprocessor word size checks."
#endif
#ifndef __RTWTYPES_H__
#error This file requires rtwtypes.h to be included
#else
#ifdef TMWTYPES_PREVIOUSLY_INCLUDED
#error This file requires rtwtypes.h to be included before tmwtypes.h
#else
#ifndef RTWTYPES_ID_C08S16I32L32N32F1
#error This code was generated with a different "rtwtypes.h" than the file included
#endif
#endif
#endif
void pid_modulator_acc_BINARYSEARCH_real_T ( uint32_T * piLeft , uint32_T *
piRght , real_T u , const real_T * pData , uint32_T iHi ) ; void
pid_modulator_acc_LookUp_real_T_real_T ( real_T * pY , const real_T * pYData
, real_T u , const real_T * pUData , uint32_T iHi ) ; extern int32_T
div_sus32_floor ( uint32_T numerator , int32_T denominator ) ; extern int32_T
div_sus32_sat ( uint32_T numerator , int32_T denominator ) ; extern void
mul_wide_u32 ( uint32_T in0 , uint32_T in1 , uint32_T * ptrOutBitsHi ,
uint32_T * ptrOutBitsLo ) ; extern uint32_T mul_u32_u32_u32_sr20 ( uint32_T a
, uint32_T b ) ; void
pid_modulator_Synthesized_Atomic_Subsystem_For_Alg_Loop_1_Init ( SimStruct *
const S ) ; void
pid_modulator_Synthesized_Atomic_Subsystem_For_Alg_Loop_1_Deriv ( SimStruct *
const S ) ; void pid_modulator_Synthesized_Atomic_Subsystem_For_Alg_Loop_1_ZC
( SimStruct * const S ) ; void
pid_modulator_Synthesized_Atomic_Subsystem_For_Alg_Loop_1_Update ( SimStruct
* const S ) ; void pid_modulator_Synthesized_Atomic_Subsystem_For_Alg_Loop_1
( SimStruct * const S ) ;
#endif
