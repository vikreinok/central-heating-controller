#include "__cf_pid_modulator2.h"
#include "pid_modulator2_acc.h"
#include "pid_modulator2_acc_private.h"
Parameters_pid_modulator2 pid_modulator2_rtDefaultParameters = { 1.0 , { 1.0
, 0.5 } , 0.0 , 0.0 , 0.1 , 0.0 , 100.0 , 1.79556868190695 , 0.1 , 0.0 ,
0.00897784340953472 , 10000.0 , - 10000.0 , 5.0 , 200.0 , 3333.0 , 0.0 ,
2936012800U , 44 , 44 , 7700 , 200 , 714 , 10000 , 200 , 2800 , 2800U , 200U
, 5U , 1U , 20000 , 20000 , 41943U , 0 , { 'a' , 'a' , 'a' , 'a' , 'a' } } ;
