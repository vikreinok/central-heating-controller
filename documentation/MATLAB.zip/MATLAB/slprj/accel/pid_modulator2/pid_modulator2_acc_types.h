#include "__cf_pid_modulator2.h"
#ifndef RTW_HEADER_pid_modulator2_acc_types_h_
#define RTW_HEADER_pid_modulator2_acc_types_h_
#include "rtwtypes.h"
typedef struct Parameters_pid_modulator2_ Parameters_pid_modulator2 ;
#endif
