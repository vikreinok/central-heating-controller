#include "__cf_pid_modulator2.h"
#include <math.h>
#include "pid_modulator2_acc.h"
#include "pid_modulator2_acc_private.h"
#include <stdio.h>
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
int32_T div_sus32_sat ( uint32_T numerator , int32_T denominator ) { int32_T
quotient ; uint32_T tempAbsQuotient ; uint32_T quotientNeedsNegation ; if (
denominator == 0 ) { quotient = MAX_int32_T ; } else { quotientNeedsNegation
= ( denominator < 0 ) ; tempAbsQuotient = numerator / ( uint32_T ) (
denominator >= 0 ? denominator : - denominator ) ; if ( ( !
quotientNeedsNegation ) && ( tempAbsQuotient >= 2147483647U ) ) { quotient =
MAX_int32_T ; } else if ( quotientNeedsNegation && ( tempAbsQuotient >
2147483647U ) ) { quotient = MIN_int32_T ; } else { quotient =
quotientNeedsNegation ? - ( int32_T ) tempAbsQuotient : ( int32_T )
tempAbsQuotient ; } } return quotient ; } int32_T div_sus32_floor ( uint32_T
numerator , int32_T denominator ) { int32_T quotient ; uint32_T
absDenominator ; uint32_T tempAbsQuotient ; uint32_T quotientNeedsNegation ;
if ( denominator == 0 ) { quotient = MAX_int32_T ; } else { absDenominator =
( uint32_T ) ( denominator >= 0 ? denominator : - denominator ) ;
quotientNeedsNegation = ( denominator < 0 ) ; tempAbsQuotient = numerator /
absDenominator ; if ( quotientNeedsNegation ) { numerator %= absDenominator ;
if ( numerator > 0 ) { tempAbsQuotient += ( uint32_T ) 1 ; } } quotient =
quotientNeedsNegation ? - ( int32_T ) tempAbsQuotient : ( int32_T )
tempAbsQuotient ; } return quotient ; } void mul_wide_u32 ( uint32_T in0 ,
uint32_T in1 , uint32_T * ptrOutBitsHi , uint32_T * ptrOutBitsLo ) { uint32_T
outBitsLo ; uint32_T in0Lo ; uint32_T in0Hi ; uint32_T in1Lo ; uint32_T in1Hi
; uint32_T productHiLo ; uint32_T productLoHi ; in0Hi = in0 >> 16U ; in0Lo =
in0 & 65535U ; in1Hi = in1 >> 16U ; in1Lo = in1 & 65535U ; productHiLo =
in0Hi * in1Lo ; productLoHi = in0Lo * in1Hi ; in0Lo *= in1Lo ; in1Lo = 0U ;
outBitsLo = ( productLoHi << 16U ) + in0Lo ; if ( outBitsLo < in0Lo ) { in1Lo
= 1U ; } in0Lo = outBitsLo ; outBitsLo += productHiLo << 16U ; if ( outBitsLo
< in0Lo ) { in1Lo ++ ; } * ptrOutBitsHi = ( ( ( productLoHi >> 16U ) + (
productHiLo >> 16U ) ) + in0Hi * in1Hi ) + in1Lo ; * ptrOutBitsLo = outBitsLo
; } uint32_T mul_u32_u32_u32_sr20 ( uint32_T a , uint32_T b ) { uint32_T
u32_chi ; uint32_T u32_clo ; mul_wide_u32 ( a , b , & u32_chi , & u32_clo ) ;
u32_clo = u32_chi << 12U | u32_clo >> 20U ; return u32_clo ; } static void
mdlOutputs ( SimStruct * S , int_T tid ) { real_T B_0_9_0 ; int16_T B_0_3_0 ;
uint16_T B_0_32_0 ; real_T B_0_23_0 ; uint32_T B_0_30_0 ; int32_T tmp ;
BlockIO_pid_modulator2 * _rtB ; Parameters_pid_modulator2 * _rtP ;
D_Work_pid_modulator2 * _rtDW ; _rtDW = ( ( D_Work_pid_modulator2 * )
ssGetRootDWork ( S ) ) ; _rtP = ( ( Parameters_pid_modulator2 * )
ssGetDefaultParam ( S ) ) ; _rtB = ( ( BlockIO_pid_modulator2 * )
_ssGetBlockIO ( S ) ) ; if ( ssIsSampleHit ( S , 2 , tid ) ) { _rtB ->
B_0_0_0 = _rtP -> P_0 * _rtDW -> DiscreteTransferFcn_states ;
ssCallAccelRunBlock ( S , 0 , 1 , SS_CALL_MDL_OUTPUTS ) ; B_0_9_0 =
muDoubleScalarFloor ( muDoubleScalarAbs ( _rtB -> B_0_0_0 ) ) ; if (
muDoubleScalarIsNaN ( B_0_9_0 ) || muDoubleScalarIsInf ( B_0_9_0 ) ) {
B_0_3_0 = 0 ; } else { B_0_3_0 = ( int16_T ) ( uint16_T ) muDoubleScalarRem (
B_0_9_0 , 65536.0 ) ; } if ( B_0_3_0 >= _rtP -> P_19 ) { _rtB -> B_0_5_0 =
B_0_3_0 ; } else { _rtB -> B_0_5_0 = _rtP -> P_18 ; } ssCallAccelRunBlock ( S
, 0 , 6 , SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 0 , 7 ,
SS_CALL_MDL_OUTPUTS ) ; B_0_9_0 = ( real_T ) _rtP -> P_20 - _rtB -> B_0_0_0 ;
_rtB -> B_0_13_0 = ( _rtP -> P_3 * B_0_9_0 - _rtDW -> Filter_DSTATE ) * _rtP
-> P_6 ; _rtB -> B_0_14_0 = _rtP -> P_7 * B_0_9_0 ; B_0_9_0 = ( _rtP -> P_10
* B_0_9_0 + _rtDW -> Integrator_DSTATE ) + _rtB -> B_0_13_0 ; if ( B_0_9_0 >=
_rtP -> P_11 ) { _rtB -> B_0_18_0 = _rtP -> P_11 ; } else if ( B_0_9_0 <=
_rtP -> P_12 ) { _rtB -> B_0_18_0 = _rtP -> P_12 ; } else { _rtB -> B_0_18_0
= B_0_9_0 ; } } if ( ssIsSampleHit ( S , 1 , tid ) ) { _rtB -> B_0_20_0 = (
uint32_T ) ( _rtP -> P_30 * _rtP -> P_21 >> 1 ) ; } if ( ssIsContinuousTask (
S , tid ) ) { ssCallAccelRunBlock ( S , 0 , 21 , SS_CALL_MDL_OUTPUTS ) ; tmp
= div_sus32_sat ( _rtB -> B_0_20_0 , ( int32_T ) _rtB -> B_0_28_0 ) ; if (
tmp < 0 ) { tmp = 0 ; } else { if ( tmp > 65535 ) { tmp = 65535 ; } }
B_0_32_0 = ( uint16_T ) tmp ; if ( ssGetTaskTime ( S , 0 ) < _rtP -> P_13 ) {
B_0_23_0 = _rtP -> P_14 ; } else { B_0_23_0 = _rtP -> P_15 ; } } if (
ssIsSampleHit ( S , 1 , tid ) ) { _rtB -> B_0_24_0 = _rtP -> P_22 ; } if (
ssIsContinuousTask ( S , tid ) ) { _rtB -> B_0_25_0 = ( B_0_23_0 < ( real_T )
_rtB -> B_0_24_0 ) ; } if ( ssIsSampleHit ( S , 1 , tid ) ) { _rtB ->
B_0_26_0 = _rtP -> P_26 ; } if ( ssIsContinuousTask ( S , tid ) ) { if ( _rtB
-> B_0_25_0 ) { _rtB -> B_0_27_0 = B_0_32_0 ; } else { _rtB -> B_0_27_0 =
_rtB -> B_0_26_0 ; } ssCallAccelRunBlock ( S , 0 , 28 , SS_CALL_MDL_OUTPUTS )
; B_0_30_0 = mul_u32_u32_u32_sr20 ( _rtP -> P_17 , ( uint32_T ) _rtB ->
B_0_28_0 ) ; } if ( ssIsSampleHit ( S , 1 , tid ) ) { _rtB -> B_0_31_0 = _rtP
-> P_23 ; } if ( ssIsContinuousTask ( S , tid ) ) { B_0_32_0 = ( uint16_T )
div_sus32_floor ( B_0_30_0 , ( int32_T ) _rtB -> B_0_31_0 ) ; } if (
ssIsSampleHit ( S , 1 , tid ) ) { _rtB -> B_0_33_0 = _rtP -> P_27 ; } if (
ssIsContinuousTask ( S , tid ) ) { if ( _rtB -> B_0_25_0 ) { _rtB -> B_0_34_0
= B_0_32_0 ; } else { _rtB -> B_0_34_0 = _rtB -> B_0_33_0 ; } } if (
ssIsSampleHit ( S , 1 , tid ) ) { _rtB -> B_0_35_0 = _rtDW ->
Memory_PreviousInput ; if ( _rtB -> B_0_35_0 ) { _rtDW ->
DiscreteTimeIntegrator_DSTATE = _rtP -> P_16 ; } _rtB -> B_0_36_0 = _rtDW ->
DiscreteTimeIntegrator_DSTATE ; _rtB -> B_0_38_0 = ( _rtB -> B_0_36_0 >= (
real_T ) _rtP -> P_28 ) ; ssCallAccelRunBlock ( S , 0 , 39 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 0 , 40 ,
SS_CALL_MDL_OUTPUTS ) ; } if ( ssIsContinuousTask ( S , tid ) ) {
ssCallAccelRunBlock ( S , 0 , 41 , SS_CALL_MDL_OUTPUTS ) ; if ( _rtB ->
B_0_38_0 ) { _rtB -> B_0_42_0 = _rtB -> B_0_44_0 ; } else { _rtB -> B_0_42_0
= _rtB -> B_0_27_0 ; } } if ( ssIsSampleHit ( S , 1 , tid ) ) {
ssCallAccelRunBlock ( S , 0 , 43 , SS_CALL_MDL_OUTPUTS ) ; } if (
ssIsContinuousTask ( S , tid ) ) { ssCallAccelRunBlock ( S , 0 , 44 ,
SS_CALL_MDL_OUTPUTS ) ; if ( _rtB -> B_0_38_0 ) { _rtB -> B_0_45_0 = _rtB ->
B_0_44_0 ; } else { _rtB -> B_0_45_0 = _rtB -> B_0_34_0 ; } } if (
ssIsSampleHit ( S , 1 , tid ) ) { ssCallAccelRunBlock ( S , 0 , 46 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_0_47_0 = _rtP -> P_29 ; tmp = div_sus32_sat
( ( uint32_T ) ( _rtP -> P_31 * _rtP -> P_24 >> 1 ) , ( int32_T ) _rtP ->
P_25 ) ; if ( tmp < 0 ) { tmp = 0 ; } else { if ( tmp > 65535 ) { tmp = 65535
; } } _rtB -> B_0_51_0 = ( uint16_T ) tmp ; ssCallAccelRunBlock ( S , 0 , 52
, SS_CALL_MDL_OUTPUTS ) ; } }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { BlockIO_pid_modulator2
* _rtB ; Parameters_pid_modulator2 * _rtP ; D_Work_pid_modulator2 * _rtDW ;
_rtDW = ( ( D_Work_pid_modulator2 * ) ssGetRootDWork ( S ) ) ; _rtP = ( (
Parameters_pid_modulator2 * ) ssGetDefaultParam ( S ) ) ; _rtB = ( (
BlockIO_pid_modulator2 * ) _ssGetBlockIO ( S ) ) ; if ( ssIsSampleHit ( S , 2
, tid ) ) { _rtDW -> DiscreteTransferFcn_states = ( _rtB -> B_0_18_0 - _rtP
-> P_1 [ 1 ] * _rtDW -> DiscreteTransferFcn_states ) / _rtP -> P_1 [ 0 ] ;
_rtDW -> Filter_DSTATE += _rtP -> P_4 * _rtB -> B_0_13_0 ; _rtDW ->
Integrator_DSTATE += _rtP -> P_8 * _rtB -> B_0_14_0 ; } if ( ssIsSampleHit (
S , 1 , tid ) ) { _rtDW -> Memory_PreviousInput = _rtB -> B_0_38_0 ; _rtDW ->
DiscreteTimeIntegrator_DSTATE += ( real_T ) _rtP -> P_32 *
2.384185791015625E-7 * ( real_T ) _rtB -> B_0_47_0 ; } } static void
mdlInitializeSizes ( SimStruct * S ) { ssSetChecksumVal ( S , 0 , 3033259474U
) ; ssSetChecksumVal ( S , 1 , 1022468863U ) ; ssSetChecksumVal ( S , 2 ,
3760892194U ) ; ssSetChecksumVal ( S , 3 , 3475755188U ) ; { mxArray *
slVerStructMat = NULL ; mxArray * slStrMat = mxCreateString ( "simulink" ) ;
char slVerChar [ 10 ] ; int status = mexCallMATLAB ( 1 , & slVerStructMat , 1
, & slStrMat , "ver" ) ; if ( status == 0 ) { mxArray * slVerMat = mxGetField
( slVerStructMat , 0 , "Version" ) ; if ( slVerMat == NULL ) { status = 1 ; }
else { status = mxGetString ( slVerMat , slVerChar , 10 ) ; } }
mxDestroyArray ( slStrMat ) ; mxDestroyArray ( slVerStructMat ) ; if ( (
status == 1 ) || ( strcmp ( slVerChar , "8.0" ) != 0 ) ) { return ; } }
ssSetOptions ( S , SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork (
S ) != sizeof ( D_Work_pid_modulator2 ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( BlockIO_pid_modulator2 ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
Parameters_pid_modulator2 ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetDefaultParam ( S , (
real_T * ) & pid_modulator2_rtDefaultParameters ) ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { } static void mdlTerminate (
SimStruct * S ) { }
#include "simulink.c"
