#include "__cf_pid_modulator2.h"
#ifndef RTW_HEADER_pid_modulator2_acc_h_
#define RTW_HEADER_pid_modulator2_acc_h_
#ifndef pid_modulator2_acc_COMMON_INCLUDES_
#define pid_modulator2_acc_COMMON_INCLUDES_
#include <stdlib.h>
#include <stddef.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "mwmathutil.h"
#endif
#include "pid_modulator2_acc_types.h"
typedef struct { real_T B_0_13_0 ; real_T B_0_14_0 ; real_T B_0_18_0 ; real_T
B_0_0_0 ; real_T B_0_36_0 ; uint32_T B_0_20_0 ; int16_T B_0_24_0 ; int16_T
B_0_31_0 ; int16_T B_0_5_0 ; int16_T B_0_28_0 ; uint16_T B_0_26_0 ; uint16_T
B_0_27_0 ; uint16_T B_0_33_0 ; uint16_T B_0_34_0 ; uint16_T B_0_42_0 ;
uint16_T B_0_45_0 ; uint16_T B_0_47_0 ; uint16_T B_0_51_0 ; uint16_T B_0_44_0
; boolean_T B_0_25_0 ; boolean_T B_0_35_0 ; boolean_T B_0_38_0 ; char
pad_B_0_38_0 [ 7 ] ; } BlockIO_pid_modulator2 ; typedef struct { real_T
DiscreteTransferFcn_states ; real_T Filter_DSTATE ; real_T Integrator_DSTATE
; real_T DiscreteTimeIntegrator_DSTATE ; real_T Sum_DWORK1 ; struct { void *
LoggedData ; } Scope_PWORK ; struct { void * LoggedData ; } Scope4_PWORK ;
void * ToWorkspace_PWORK ; void * FromWorkspace2_PWORK [ 3 ] ; void *
FromWorkspace2_PWORK_j [ 3 ] ; struct { void * LoggedData ; } Scope1_PWORK ;
struct { void * LoggedData ; } Scope3_PWORK ; void * FromWorkspace2_PWORK_j2
[ 3 ] ; void * ToWorkspace4_PWORK ; void * FromWorkspace1_PWORK [ 3 ] ; void
* ToWorkspace5_PWORK ; struct { void * LoggedData ; } Scope2_PWORK ; int_T
FromWorkspace2_IWORK ; int_T FromWorkspace2_IWORK_k ; int_T
FromWorkspace2_IWORK_p ; int_T FromWorkspace1_IWORK ; boolean_T
Memory_PreviousInput ; char pad_Memory_PreviousInput [ 7 ] ; }
D_Work_pid_modulator2 ; struct Parameters_pid_modulator2_ { real_T P_0 ;
real_T P_1 [ 2 ] ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T
P_6 ; real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11 ;
real_T P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ; real_T P_16 ;
uint32_T P_17 ; int16_T P_18 ; int16_T P_19 ; int16_T P_20 ; int16_T P_21 ;
int16_T P_22 ; int16_T P_23 ; int16_T P_24 ; int16_T P_25 ; uint16_T P_26 ;
uint16_T P_27 ; uint16_T P_28 ; uint16_T P_29 ; int16_T P_30 ; int16_T P_31 ;
uint16_T P_32 ; boolean_T P_33 ; char pad_P_33 [ 5 ] ; } ; extern
Parameters_pid_modulator2 pid_modulator2_rtDefaultParameters ;
#endif
