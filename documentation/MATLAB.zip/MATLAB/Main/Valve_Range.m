% mitttelineaarne klapi karakteristik
% f(u) = Q/Qmax = R^-(1-u) - equal percentage, ekponentsiaalne karakter.
% R= 30...50 -reguleerimise ulatus (rangeability), mittehermeetilisus Qmin ei ole 0

u=0:0.1:1; R=[30 40 50];
fu(1,:)=1./R(1).^(1-u);
fu(2,:)=1./R(2).^(1-u);
fu(3,:)=1./R(3).^(1-u);
plot(u,fu), grid