% Klapi Kv - klapi v�imsuse konstant
% n�itab l�binud vedeliku hulka [m3] �hes tunnis, 
% kui r�hulang(dP) klapil on 1 Bar [kg/cm2](=10 000 Pa [N/m2]) 
% = c 0.1 atm [kgf/cm2]
% (kui vedeliku tihedus on 1000 kg/m3 ja kinematic viscosity 100000 m2/s)
roo_ref = 1000; % [kg/m3] water dentsity @ 20
%
% kv = Q / sqrt(dP) [m3/h]
% nt. soojusvaheti ees 1.8 [l/s] = 6.5 [m3/h]
% dP = 50 kPa = 0.50 bar
% kv = 9.2; sobib klapp mille kv on nt 10
Q = 6.5; dP = 0.5; kv = Q/sqrt(dP);

% Veel on Cv (Valve Flow Coefficent| Cv-factor |flow factor Cv)
% UK Cv - UK gallon(4.546 l) in minute @ dP = 1 pound per square inch (psi)
% 1 Cv = 1 kv * 0.97
% US Cv - US gallon(3.785 l) in minute @ dP = 1 pound per square inch
% 1 Cv = 1 kv * 1.17
Cv=kv*1.17;

% T�psemalt arvestades vedeliku tiheduse erinevust veest:
roo = 1000; % [kg/m3] vedeliku tihedus
Qmax = Cv*sqrt(dP/(roo/roo_ref)) %[gal/min]
Qmax = kv*sqrt(dP/(roo/roo_ref)) %[m3/h]
 
% f(u) - klapi karakteristik (inherent characteristic)| dP=constant 
% 0 < u < 1 , t�ielikult suletust kuni t�ielikult avatuni
% Q(t)= kv.f(u).sqrt(dP/(roo/roo_ref)) [m3/h] ruumala kulu
% Q(t)= kv.f(u).sqrt(dP*roo)[?kg/h] massi kulu
% f(u) = Q/Qmax = u  - lineaarne karakteristik 
% f(u) = Q/Qmax = R^-(1-u) - equal percentage, ekponentsiaalne karakter.
% R= 30...50 -reguleerimise ulatus (rangeability), mittehermeetilisus Qmin ei ole 0

% K - kaotegur (takistus) loss coef. turbulentsel v�ga voolust ei s�ltu
K = 2*dP/(roo*Q^2)
A = 0.001 % Klapi ava pindala [ 2]
K= ((A/Cv)^2)*(2/roo)
