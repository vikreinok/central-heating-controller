% House model
% 02.02.2008/SGt

clc
close all
clear

C   = 100000;   % [J/kgK] Heat capacity
T_a = 0;        % [�C] Temperature, ambient
K   = 100;      % [W/�C] Coeff. of heat loss
Q_R = 1500;     % [W] Radiator heat
T_init  = 5;    % [�C] Initial value

t_F = 2*3600;   % [s] Time for free heat input
Q_F = 1000;     % [W] Heat input

t_sim   = 6*3600;   % [s] Simulation time

sim('house_model',t_sim)

plot(t/3600,T)
grid
xlabel('t [h]')
ylabel('T [�C]')



