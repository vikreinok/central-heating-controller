/*
 * File: Controller.h
 *
 * Code generated for Simulink model 'Controller'.
 *
 * Model version                  : 1.89
 * Simulink Coder version         : 8.3 (R2012b) 20-Jul-2012
 * TLC version                    : 8.3 (Jul 21 2012)
 * C/C++ source code generated on : Wed Jun 11 22:38:08 2014
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Microchip->PIC18
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Controller_h_
#define RTW_HEADER_Controller_h_
#include "rtwtypes.h"
#ifndef Controller_COMMON_INCLUDES_
# define Controller_COMMON_INCLUDES_
#include <stddef.h>
#include "rtwtypes.h"
#endif                                 /* Controller_COMMON_INCLUDES_ */

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM_Controller RT_MODEL_Controller;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  real_T error;                        /* '<Root>/error' */
} ExternalInputs_Controller;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  real_T controlsignal;                /* '<Root>/control signal' */
} ExternalOutputs_Controller;

/* Parameters (auto storage) */
struct Parameters_Controller_ {
  real_T ProportionalGain_Gain;        /* Expression: P
                                        * Referenced by: '<S2>/Proportional Gain'
                                        */
  real_T Saturation_UpperSat;          /* Expression: UpperSaturationLimit
                                        * Referenced by: '<S2>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: LowerSaturationLimit
                                        * Referenced by: '<S2>/Saturation'
                                        */
};

/* Parameters (auto storage) */
typedef struct Parameters_Controller_ Parameters_Controller;

/* Real-time Model Data Structure */
struct tag_RTM_Controller {
  const char_T * volatile errorStatus;
};

/* Block parameters (auto storage) */
extern Parameters_Controller Controller_P;

/* External inputs (root inport signals with auto storage) */
extern ExternalInputs_Controller Controller_U;

/* External outputs (root outports fed by signals with auto storage) */
extern ExternalOutputs_Controller Controller_Y;

/* Model entry point functions */
void Controller_initialize(void);
void Controller_step(void);

/* Real-time Model object */
extern RT_MODEL_Controller *const Controller_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('pid_modulator/Controller')    - opens subsystem pid_modulator/Controller
 * hilite_system('pid_modulator/Controller/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'pid_modulator'
 * '<S1>'   : 'pid_modulator/Controller'
 * '<S2>'   : 'pid_modulator/Controller/Discrete_PID_Controller'
 */
#endif                                 /* RTW_HEADER_Controller_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
