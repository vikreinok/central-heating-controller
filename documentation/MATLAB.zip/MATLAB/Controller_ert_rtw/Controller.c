/*
 * File: Controller.c
 *
 * Code generated for Simulink model 'Controller'.
 *
 * Model version                  : 1.89
 * Simulink Coder version         : 8.3 (R2012b) 20-Jul-2012
 * TLC version                    : 8.3 (Jul 21 2012)
 * C/C++ source code generated on : Wed Jun 11 22:38:08 2014
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Microchip->PIC18
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Controller.h"

/* Block parameters (auto storage) */
Parameters_Controller Controller_P = {
  3000.0,                              /* Expression: P
                                        * Referenced by: '<S2>/Proportional Gain'
                                        */
  10000.0,                             /* Expression: UpperSaturationLimit
                                        * Referenced by: '<S2>/Saturation'
                                        */
  -10000.0                             /* Expression: LowerSaturationLimit
                                        * Referenced by: '<S2>/Saturation'
                                        */
};

/* External inputs (root inport signals with auto storage) */
ExternalInputs_Controller Controller_U;

/* External outputs (root outports fed by signals with auto storage) */
ExternalOutputs_Controller Controller_Y;

/* Real-time model */
RT_MODEL_Controller Controller_M_;
RT_MODEL_Controller *const Controller_M = &Controller_M_;

/* Model step function */
void Controller_step(void)
{
  real_T u;

  /* Gain: '<S2>/Proportional Gain' incorporates:
   *  Inport: '<Root>/error'
   */
  u = Controller_P.ProportionalGain_Gain * Controller_U.error;

  /* Saturate: '<S2>/Saturation' */
  if (u >= Controller_P.Saturation_UpperSat) {
    /* Outport: '<Root>/control signal' */
    Controller_Y.controlsignal = Controller_P.Saturation_UpperSat;
  } else if (u <= Controller_P.Saturation_LowerSat) {
    /* Outport: '<Root>/control signal' */
    Controller_Y.controlsignal = Controller_P.Saturation_LowerSat;
  } else {
    /* Outport: '<Root>/control signal' */
    Controller_Y.controlsignal = u;
  }

  /* End of Saturate: '<S2>/Saturation' */
}

/* Model initialize function */
void Controller_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(Controller_M, (NULL));

  /* external inputs */
  Controller_U.error = 0.0;

  /* external outputs */
  Controller_Y.controlsignal = 0.0;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
