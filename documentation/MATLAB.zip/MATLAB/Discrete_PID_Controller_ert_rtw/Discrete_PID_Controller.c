/*
 * File: Discrete_PID_Controller.c
 *
 * Code generated for Simulink model 'Discrete_PID_Controller'.
 *
 * Model version                  : 1.87
 * Simulink Coder version         : 8.3 (R2012b) 20-Jul-2012
 * TLC version                    : 8.3 (Jul 21 2012)
 * C/C++ source code generated on : Tue Aug 13 17:36:21 2013
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Microchip->PIC18
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Discrete_PID_Controller.h"

/* Block parameters (auto storage) */
Parameters_Discrete_PID_Control Discrete_PID_Controller_P = {
  1000.0,                              /* Expression: P
                                        * Referenced by: '<S1>/Proportional Gain'
                                        */
  10000.0,                             /* Expression: UpperSaturationLimit
                                        * Referenced by: '<S1>/Saturation'
                                        */
  -10000.0                             /* Expression: LowerSaturationLimit
                                        * Referenced by: '<S1>/Saturation'
                                        */
};

/* External inputs (root inport signals with auto storage) */
ExternalInputs_Discrete_PID_Con Discrete_PID_Controller_U;

/* External outputs (root outports fed by signals with auto storage) */
ExternalOutputs_Discrete_PID_Co Discrete_PID_Controller_Y;

/* Real-time model */
RT_MODEL_Discrete_PID_Controlle Discrete_PID_Controller_M_;
RT_MODEL_Discrete_PID_Controlle *const Discrete_PID_Controller_M =
  &Discrete_PID_Controller_M_;

/* Model step function */
void Discrete_PID_Controller_step(void)
{
  real_T u;

  /* Gain: '<S1>/Proportional Gain' incorporates:
   *  Inport: '<Root>/u'
   */
  u = Discrete_PID_Controller_P.ProportionalGain_Gain *
    Discrete_PID_Controller_U.errorf;

  /* Saturate: '<S1>/Saturation' */
  if (u >= Discrete_PID_Controller_P.Saturation_UpperSat) {
    /* Outport: '<Root>/y' */
    Discrete_PID_Controller_Y.y = Discrete_PID_Controller_P.Saturation_UpperSat;
  } else if (u <= Discrete_PID_Controller_P.Saturation_LowerSat) {
    /* Outport: '<Root>/y' */
    Discrete_PID_Controller_Y.y = Discrete_PID_Controller_P.Saturation_LowerSat;
  } else {
    /* Outport: '<Root>/y' */
    Discrete_PID_Controller_Y.y = u;
  }

  /* End of Saturate: '<S1>/Saturation' */
}

/* Model initialize function */
void Discrete_PID_Controller_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(Discrete_PID_Controller_M, (NULL));

  /* external inputs */
  Discrete_PID_Controller_U.errorf = 0.0;

  /* external outputs */
  Discrete_PID_Controller_Y.y = 0.0;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
