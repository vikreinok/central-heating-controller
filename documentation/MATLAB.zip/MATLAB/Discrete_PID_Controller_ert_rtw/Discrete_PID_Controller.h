/*
 * File: Discrete_PID_Controller.h
 *
 * Code generated for Simulink model 'Discrete_PID_Controller'.
 *
 * Model version                  : 1.87
 * Simulink Coder version         : 8.3 (R2012b) 20-Jul-2012
 * TLC version                    : 8.3 (Jul 21 2012)
 * C/C++ source code generated on : Tue Aug 13 17:36:21 2013
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Microchip->PIC18
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Discrete_PID_Controller_h_
#define RTW_HEADER_Discrete_PID_Controller_h_
#include "rtwtypes.h"
#ifndef Discrete_PID_Controller_COMMON_INCLUDES_
# define Discrete_PID_Controller_COMMON_INCLUDES_
#include <stddef.h>
#include "rtwtypes.h"
#endif                                 /* Discrete_PID_Controller_COMMON_INCLUDES_ */

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM_Discrete_PID_Controller RT_MODEL_Discrete_PID_Controlle;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  real_T errorf;                       /* '<Root>/u' */
} ExternalInputs_Discrete_PID_Con;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  real_T y;                            /* '<Root>/y' */
} ExternalOutputs_Discrete_PID_Co;

/* Parameters (auto storage) */
struct Parameters_Discrete_PID_Control_ {
  real_T ProportionalGain_Gain;        /* Expression: P
                                        * Referenced by: '<S1>/Proportional Gain'
                                        */
  real_T Saturation_UpperSat;          /* Expression: UpperSaturationLimit
                                        * Referenced by: '<S1>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: LowerSaturationLimit
                                        * Referenced by: '<S1>/Saturation'
                                        */
};

/* Parameters (auto storage) */
typedef struct Parameters_Discrete_PID_Control_ Parameters_Discrete_PID_Control;

/* Real-time Model Data Structure */
struct tag_RTM_Discrete_PID_Controller {
  const char_T * volatile errorStatus;
};

/* Block parameters (auto storage) */
extern Parameters_Discrete_PID_Control Discrete_PID_Controller_P;

/* External inputs (root inport signals with auto storage) */
extern ExternalInputs_Discrete_PID_Con Discrete_PID_Controller_U;

/* External outputs (root outports fed by signals with auto storage) */
extern ExternalOutputs_Discrete_PID_Co Discrete_PID_Controller_Y;

/* Model entry point functions */
void Discrete_PID_Controller_initialize(void);
void Discrete_PID_Controller_step(void);

/* Real-time Model object */
extern RT_MODEL_Discrete_PID_Controlle *const Discrete_PID_Controller_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('pid_modulator/Controller/Discrete_PID_Controller')    - opens subsystem pid_modulator/Controller/Discrete_PID_Controller
 * hilite_system('pid_modulator/Controller/Discrete_PID_Controller/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'pid_modulator/Controller'
 * '<S1>'   : 'pid_modulator/Controller/Discrete_PID_Controller'
 */
#endif                                 /* RTW_HEADER_Discrete_PID_Controller_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
