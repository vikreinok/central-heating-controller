  
%Coefficients (with 95% confidence bounds):
       a =       1.375; 
       b =      0.5485;
       
       
       x=0:0.01:20;
         y=a*x.^b;

plot(x,y), grid