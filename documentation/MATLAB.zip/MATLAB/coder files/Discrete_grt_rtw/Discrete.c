/*
 * Discrete.c
 *
 * Code generation for model "Discrete".
 *
 * Model version              : 1.85
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Sat Jun 08 20:54:43 2013
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Microchip->PIC18
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "Discrete.h"
#include "Discrete_private.h"

/* Block signals (auto storage) */
BlockIO_Discrete Discrete_B;

/* Block states (auto storage) */
D_Work_Discrete Discrete_DWork;

/* External inputs (root inport signals with auto storage) */
ExternalInputs_Discrete Discrete_U;

/* External outputs (root outports fed by signals with auto storage) */
ExternalOutputs_Discrete Discrete_Y;

/* Real-time model */
RT_MODEL_Discrete Discrete_M_;
RT_MODEL_Discrete *const Discrete_M = &Discrete_M_;

/* Model output function */
static void Discrete_output(void)
{
  int32_T tmp;
  int16_T rtb_Saturation;

  /* Sum: '<S1>/Sum' incorporates:
   *  DiscreteIntegrator: '<S1>/Integrator'
   *  Gain: '<S1>/Proportional Gain'
   *  Inport: '<Root>/u'
   */
  rtb_Saturation = (int16_T)((int32_T)Discrete_P.ProportionalGain_Gain *
    (int32_T)Discrete_U.errorf >> 15) + (Discrete_DWork.Integrator_DSTATE << 1);

  /* Saturate: '<S1>/Saturation' */
  tmp = (int32_T)rtb_Saturation << 2;
  if (tmp >= (int32_T)Discrete_P.Saturation_UpperSat) {
    /* Outport: '<Root>/y' */
    Discrete_Y.y = Discrete_P.Saturation_UpperSat;
  } else if (tmp <= (int32_T)Discrete_P.Saturation_LowerSat) {
    /* Outport: '<Root>/y' */
    Discrete_Y.y = Discrete_P.Saturation_LowerSat;
  } else {
    /* Outport: '<Root>/y' */
    Discrete_Y.y = rtb_Saturation << 2;
  }

  /* End of Saturate: '<S1>/Saturation' */

  /* Gain: '<S1>/Integral Gain' incorporates:
   *  Inport: '<Root>/u'
   */
  Discrete_B.IntegralGain = (int16_T)((int32_T)Discrete_P.IntegralGain_Gain *
    (int32_T)Discrete_U.errorf >> 15);
}

/* Model update function */
static void Discrete_update(void)
{
  /* Update for DiscreteIntegrator: '<S1>/Integrator' */
  Discrete_DWork.Integrator_DSTATE += (int16_T)((int32_T)
    Discrete_P.Integrator_gainval * (int32_T)Discrete_B.IntegralGain >> 27);

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Discrete_M->Timing.clockTick0)) {
    ++Discrete_M->Timing.clockTickH0;
  }

  Discrete_M->Timing.t[0] = Discrete_M->Timing.clockTick0 *
    Discrete_M->Timing.stepSize0 + Discrete_M->Timing.clockTickH0 *
    Discrete_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void Discrete_initialize(void)
{
  /* InitializeConditions for DiscreteIntegrator: '<S1>/Integrator' */
  Discrete_DWork.Integrator_DSTATE = Discrete_P.Integrator_IC;
}

/* Model terminate function */
void Discrete_terminate(void)
{
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  Discrete_output();

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  Discrete_update();

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  Discrete_initialize();
}

void MdlTerminate(void)
{
  Discrete_terminate();
}

RT_MODEL_Discrete *Discrete(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Discrete_M, 0,
                sizeof(RT_MODEL_Discrete));

  /* Initialize timing info */
  {
    int_T *mdlTsMap = Discrete_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    Discrete_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    Discrete_M->Timing.sampleTimes = (&Discrete_M->Timing.sampleTimesArray[0]);
    Discrete_M->Timing.offsetTimes = (&Discrete_M->Timing.offsetTimesArray[0]);

    /* task periods */
    Discrete_M->Timing.sampleTimes[0] = (0.1);

    /* task offsets */
    Discrete_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(Discrete_M, &Discrete_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = Discrete_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    Discrete_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(Discrete_M, 12000.0);
  Discrete_M->Timing.stepSize0 = 0.1;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    Discrete_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(Discrete_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(Discrete_M->rtwLogInfo, (NULL));
    rtliSetLogT(Discrete_M->rtwLogInfo, "tout");
    rtliSetLogX(Discrete_M->rtwLogInfo, "");
    rtliSetLogXFinal(Discrete_M->rtwLogInfo, "");
    rtliSetSigLog(Discrete_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(Discrete_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(Discrete_M->rtwLogInfo, 0);
    rtliSetLogMaxRows(Discrete_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(Discrete_M->rtwLogInfo, 1);

    /*
     * Set pointers to the data and signal info for each output
     */
    {
      static void * rt_LoggedOutputSignalPtrs[] = {
        &Discrete_Y.y
      };

      rtliSetLogYSignalPtrs(Discrete_M->rtwLogInfo, ((LogSignalPtrsType)
        rt_LoggedOutputSignalPtrs));
    }

    {
      static int_T rt_LoggedOutputWidths[] = {
        1
      };

      static int_T rt_LoggedOutputNumDimensions[] = {
        1
      };

      static int_T rt_LoggedOutputDimensions[] = {
        1
      };

      static boolean_T rt_LoggedOutputIsVarDims[] = {
        0
      };

      static void* rt_LoggedCurrentSignalDimensions[] = {
        (NULL)
      };

      static int_T rt_LoggedCurrentSignalDimensionsSize[] = {
        2
      };

      static BuiltInDTypeId rt_LoggedOutputDataTypeIds[] = {
        SS_DOUBLE
      };

      static int_T rt_LoggedOutputComplexSignals[] = {
        0
      };

      static const char_T *rt_LoggedOutputLabels[] = {
        "" };

      static const char_T *rt_LoggedOutputBlockNames[] = {
        "Discrete/y" };

      static RTWLogDataTypeConvert rt_RTWLogDataTypeConvert[] = {
        { 1, SS_DOUBLE, SS_INT16, 32, 1, 1, 1.0, -1, 0.0 }
      };

      static RTWLogSignalInfo rt_LoggedOutputSignalInfo[] = {
        {
          1,
          rt_LoggedOutputWidths,
          rt_LoggedOutputNumDimensions,
          rt_LoggedOutputDimensions,
          rt_LoggedOutputIsVarDims,
          rt_LoggedCurrentSignalDimensions,
          rt_LoggedCurrentSignalDimensionsSize,
          rt_LoggedOutputDataTypeIds,
          rt_LoggedOutputComplexSignals,
          (NULL),

          { rt_LoggedOutputLabels },
          (NULL),
          (NULL),
          (NULL),

          { rt_LoggedOutputBlockNames },

          { (NULL) },
          (NULL),
          rt_RTWLogDataTypeConvert
        }
      };

      rtliSetLogYSignalInfo(Discrete_M->rtwLogInfo, rt_LoggedOutputSignalInfo);

      /* set currSigDims field */
      rt_LoggedCurrentSignalDimensions[0] = &rt_LoggedOutputWidths[0];
    }

    rtliSetLogY(Discrete_M->rtwLogInfo, "yout");
  }

  Discrete_M->solverInfoPtr = (&Discrete_M->solverInfo);
  Discrete_M->Timing.stepSize = (0.1);
  rtsiSetFixedStepSize(&Discrete_M->solverInfo, 0.1);
  rtsiSetSolverMode(&Discrete_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  Discrete_M->ModelData.blockIO = ((void *) &Discrete_B);
  (void) memset(((void *) &Discrete_B), 0,
                sizeof(BlockIO_Discrete));

  /* parameters */
  Discrete_M->ModelData.defaultParam = ((real_T *)&Discrete_P);

  /* states (dwork) */
  Discrete_M->Work.dwork = ((void *) &Discrete_DWork);
  (void) memset((void *)&Discrete_DWork, 0,
                sizeof(D_Work_Discrete));

  /* external inputs */
  Discrete_M->ModelData.inputs = (((void*)&Discrete_U));
  Discrete_U.errorf = 0;

  /* external outputs */
  Discrete_M->ModelData.outputs = (&Discrete_Y);
  Discrete_Y.y = 0;

  /* Initialize Sizes */
  Discrete_M->Sizes.numContStates = (0);/* Number of continuous states */
  Discrete_M->Sizes.numY = (1);        /* Number of model outputs */
  Discrete_M->Sizes.numU = (1);        /* Number of model inputs */
  Discrete_M->Sizes.sysDirFeedThru = (1);/* The model is direct feedthrough */
  Discrete_M->Sizes.numSampTimes = (1);/* Number of sample times */
  Discrete_M->Sizes.numBlocks = (6);   /* Number of blocks */
  Discrete_M->Sizes.numBlockIO = (1);  /* Number of block outputs */
  Discrete_M->Sizes.numBlockPrms = (6);/* Sum of parameter "widths" */
  return Discrete_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
