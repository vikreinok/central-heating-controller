/*
 * Discrete_types.h
 *
 * Code generation for model "Discrete".
 *
 * Model version              : 1.85
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Sat Jun 08 20:54:43 2013
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Microchip->PIC18
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_Discrete_types_h_
#define RTW_HEADER_Discrete_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct Parameters_Discrete_ Parameters_Discrete;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Discrete RT_MODEL_Discrete;

#endif                                 /* RTW_HEADER_Discrete_types_h_ */
