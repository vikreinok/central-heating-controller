/*
 * File: Discrete_PID_Controller_types.h
 *
 * Code generated for Simulink model 'Discrete_PID_Controller'.
 *
 * Model version                  : 1.85
 * Simulink Coder version         : 8.3 (R2012b) 20-Jul-2012
 * TLC version                    : 8.3 (Jul 21 2012)
 * C/C++ source code generated on : Sat Jun 08 21:05:46 2013
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Microchip->PIC18
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Discrete_PID_Controller_types_h_
#define RTW_HEADER_Discrete_PID_Controller_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct Parameters_Discrete_PID_Control_ Parameters_Discrete_PID_Control;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Discrete_PID_Controller RT_MODEL_Discrete_PID_Controlle;

#endif                                 /* RTW_HEADER_Discrete_PID_Controller_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
