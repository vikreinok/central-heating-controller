/*
 * File: Discrete_PID_Controller.c
 *
 * Code generated for Simulink model 'Discrete_PID_Controller'.
 *
 * Model version                  : 1.85
 * Simulink Coder version         : 8.3 (R2012b) 20-Jul-2012
 * TLC version                    : 8.3 (Jul 21 2012)
 * C/C++ source code generated on : Sat Jun 08 21:05:46 2013
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Microchip->PIC18
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Discrete_PID_Controller.h"
#include "Discrete_PID_Controller_private.h"

/* Block states (auto storage) */
D_Work_Discrete_PID_Controller Discrete_PID_Controller_DWork;

/* External inputs (root inport signals with auto storage) */
ExternalInputs_Discrete_PID_Con Discrete_PID_Controller_U;

/* External outputs (root outports fed by signals with auto storage) */
ExternalOutputs_Discrete_PID_Co Discrete_PID_Controller_Y;

/* Real-time model */
RT_MODEL_Discrete_PID_Controlle Discrete_PID_Controller_M_;
RT_MODEL_Discrete_PID_Controlle *const Discrete_PID_Controller_M =
  &Discrete_PID_Controller_M_;

/* Model step function */
void Discrete_PID_Controller_step(void)
{
  int32_T tmp;
  int16_T rtb_Saturation;

  /* Sum: '<S1>/Sum' incorporates:
   *  DiscreteIntegrator: '<S1>/Integrator'
   *  Gain: '<S1>/Proportional Gain'
   *  Inport: '<Root>/u'
   */
  rtb_Saturation = (int16_T)((int32_T)
    Discrete_PID_Controller_P.ProportionalGain_Gain * (int32_T)
    Discrete_PID_Controller_U.errorf >> 15) +
    (Discrete_PID_Controller_DWork.Integrator_DSTATE << 1);

  /* Saturate: '<S1>/Saturation' */
  tmp = (int32_T)rtb_Saturation << 2;
  if (tmp >= (int32_T)Discrete_PID_Controller_P.Saturation_UpperSat) {
    /* Outport: '<Root>/y' */
    Discrete_PID_Controller_Y.y = Discrete_PID_Controller_P.Saturation_UpperSat;
  } else if (tmp <= (int32_T)Discrete_PID_Controller_P.Saturation_LowerSat) {
    /* Outport: '<Root>/y' */
    Discrete_PID_Controller_Y.y = Discrete_PID_Controller_P.Saturation_LowerSat;
  } else {
    /* Outport: '<Root>/y' */
    Discrete_PID_Controller_Y.y = rtb_Saturation << 2;
  }

  /* End of Saturate: '<S1>/Saturation' */

  /* Update for DiscreteIntegrator: '<S1>/Integrator' incorporates:
   *  Gain: '<S1>/Integral Gain'
   *  Inport: '<Root>/u'
   */
  Discrete_PID_Controller_DWork.Integrator_DSTATE += (int16_T)((int32_T)(int16_T)
    ((int32_T)Discrete_PID_Controller_P.IntegralGain_Gain * (int32_T)
     Discrete_PID_Controller_U.errorf >> 15) * (int32_T)
    Discrete_PID_Controller_P.Integrator_gainval >> 27);
}

/* Model initialize function */
void Discrete_PID_Controller_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(Discrete_PID_Controller_M, (NULL));

  /* states (dwork) */
  (void) memset((void *)&Discrete_PID_Controller_DWork, 0,
                sizeof(D_Work_Discrete_PID_Controller));

  /* external inputs */
  Discrete_PID_Controller_U.errorf = 0;

  /* external outputs */
  Discrete_PID_Controller_Y.y = 0;

  /* InitializeConditions for DiscreteIntegrator: '<S1>/Integrator' */
  Discrete_PID_Controller_DWork.Integrator_DSTATE =
    Discrete_PID_Controller_P.Integrator_IC;
}

/* Model terminate function */
void Discrete_PID_Controller_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
