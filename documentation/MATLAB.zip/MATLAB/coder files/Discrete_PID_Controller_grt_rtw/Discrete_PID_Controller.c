/*
 * Discrete_PID_Controller.c
 *
 * Code generation for model "Discrete_PID_Controller".
 *
 * Model version              : 1.85
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Sat Jun 08 20:59:35 2013
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Microchip->PIC18
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "Discrete_PID_Controller.h"
#include "Discrete_PID_Controller_private.h"

/* Block signals (auto storage) */
BlockIO_Discrete_PID_Controller Discrete_PID_Controller_B;

/* Block states (auto storage) */
D_Work_Discrete_PID_Controller Discrete_PID_Controller_DWork;

/* External inputs (root inport signals with auto storage) */
ExternalInputs_Discrete_PID_Con Discrete_PID_Controller_U;

/* External outputs (root outports fed by signals with auto storage) */
ExternalOutputs_Discrete_PID_Co Discrete_PID_Controller_Y;

/* Real-time model */
RT_MODEL_Discrete_PID_Controlle Discrete_PID_Controller_M_;
RT_MODEL_Discrete_PID_Controlle *const Discrete_PID_Controller_M =
  &Discrete_PID_Controller_M_;

/* Model output function */
static void Discrete_PID_Controller_output(void)
{
  int32_T tmp;
  int16_T rtb_Saturation;

  /* Sum: '<S1>/Sum' incorporates:
   *  DiscreteIntegrator: '<S1>/Integrator'
   *  Gain: '<S1>/Proportional Gain'
   *  Inport: '<Root>/u'
   */
  rtb_Saturation = (int16_T)((int32_T)
    Discrete_PID_Controller_P.ProportionalGain_Gain * (int32_T)
    Discrete_PID_Controller_U.errorf >> 15) +
    (Discrete_PID_Controller_DWork.Integrator_DSTATE << 1);

  /* Saturate: '<S1>/Saturation' */
  tmp = (int32_T)rtb_Saturation << 2;
  if (tmp >= (int32_T)Discrete_PID_Controller_P.Saturation_UpperSat) {
    /* Outport: '<Root>/y' */
    Discrete_PID_Controller_Y.y = Discrete_PID_Controller_P.Saturation_UpperSat;
  } else if (tmp <= (int32_T)Discrete_PID_Controller_P.Saturation_LowerSat) {
    /* Outport: '<Root>/y' */
    Discrete_PID_Controller_Y.y = Discrete_PID_Controller_P.Saturation_LowerSat;
  } else {
    /* Outport: '<Root>/y' */
    Discrete_PID_Controller_Y.y = rtb_Saturation << 2;
  }

  /* End of Saturate: '<S1>/Saturation' */

  /* Gain: '<S1>/Integral Gain' incorporates:
   *  Inport: '<Root>/u'
   */
  Discrete_PID_Controller_B.IntegralGain = (int16_T)((int32_T)
    Discrete_PID_Controller_P.IntegralGain_Gain * (int32_T)
    Discrete_PID_Controller_U.errorf >> 15);
}

/* Model update function */
static void Discrete_PID_Controller_update(void)
{
  /* Update for DiscreteIntegrator: '<S1>/Integrator' */
  Discrete_PID_Controller_DWork.Integrator_DSTATE += (int16_T)((int32_T)
    Discrete_PID_Controller_P.Integrator_gainval * (int32_T)
    Discrete_PID_Controller_B.IntegralGain >> 27);

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Discrete_PID_Controller_M->Timing.clockTick0)) {
    ++Discrete_PID_Controller_M->Timing.clockTickH0;
  }

  Discrete_PID_Controller_M->Timing.t[0] =
    Discrete_PID_Controller_M->Timing.clockTick0 *
    Discrete_PID_Controller_M->Timing.stepSize0 +
    Discrete_PID_Controller_M->Timing.clockTickH0 *
    Discrete_PID_Controller_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void Discrete_PID_Controller_initialize(void)
{
  /* InitializeConditions for DiscreteIntegrator: '<S1>/Integrator' */
  Discrete_PID_Controller_DWork.Integrator_DSTATE =
    Discrete_PID_Controller_P.Integrator_IC;
}

/* Model terminate function */
void Discrete_PID_Controller_terminate(void)
{
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  Discrete_PID_Controller_output();

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  Discrete_PID_Controller_update();

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  Discrete_PID_Controller_initialize();
}

void MdlTerminate(void)
{
  Discrete_PID_Controller_terminate();
}

RT_MODEL_Discrete_PID_Controlle *Discrete_PID_Controller(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Discrete_PID_Controller_M, 0,
                sizeof(RT_MODEL_Discrete_PID_Controlle));

  /* Initialize timing info */
  {
    int_T *mdlTsMap = Discrete_PID_Controller_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    Discrete_PID_Controller_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    Discrete_PID_Controller_M->Timing.sampleTimes =
      (&Discrete_PID_Controller_M->Timing.sampleTimesArray[0]);
    Discrete_PID_Controller_M->Timing.offsetTimes =
      (&Discrete_PID_Controller_M->Timing.offsetTimesArray[0]);

    /* task periods */
    Discrete_PID_Controller_M->Timing.sampleTimes[0] = (0.1);

    /* task offsets */
    Discrete_PID_Controller_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(Discrete_PID_Controller_M,
             &Discrete_PID_Controller_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = Discrete_PID_Controller_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    Discrete_PID_Controller_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(Discrete_PID_Controller_M, 12000.0);
  Discrete_PID_Controller_M->Timing.stepSize0 = 0.1;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    Discrete_PID_Controller_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(Discrete_PID_Controller_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(Discrete_PID_Controller_M->rtwLogInfo, (NULL));
    rtliSetLogT(Discrete_PID_Controller_M->rtwLogInfo, "tout");
    rtliSetLogX(Discrete_PID_Controller_M->rtwLogInfo, "");
    rtliSetLogXFinal(Discrete_PID_Controller_M->rtwLogInfo, "");
    rtliSetSigLog(Discrete_PID_Controller_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(Discrete_PID_Controller_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(Discrete_PID_Controller_M->rtwLogInfo, 0);
    rtliSetLogMaxRows(Discrete_PID_Controller_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(Discrete_PID_Controller_M->rtwLogInfo, 1);

    /*
     * Set pointers to the data and signal info for each output
     */
    {
      static void * rt_LoggedOutputSignalPtrs[] = {
        &Discrete_PID_Controller_Y.y
      };

      rtliSetLogYSignalPtrs(Discrete_PID_Controller_M->rtwLogInfo,
                            ((LogSignalPtrsType)rt_LoggedOutputSignalPtrs));
    }

    {
      static int_T rt_LoggedOutputWidths[] = {
        1
      };

      static int_T rt_LoggedOutputNumDimensions[] = {
        1
      };

      static int_T rt_LoggedOutputDimensions[] = {
        1
      };

      static boolean_T rt_LoggedOutputIsVarDims[] = {
        0
      };

      static void* rt_LoggedCurrentSignalDimensions[] = {
        (NULL)
      };

      static int_T rt_LoggedCurrentSignalDimensionsSize[] = {
        2
      };

      static BuiltInDTypeId rt_LoggedOutputDataTypeIds[] = {
        SS_DOUBLE
      };

      static int_T rt_LoggedOutputComplexSignals[] = {
        0
      };

      static const char_T *rt_LoggedOutputLabels[] = {
        "" };

      static const char_T *rt_LoggedOutputBlockNames[] = {
        "Discrete_PID_Controller/y" };

      static RTWLogDataTypeConvert rt_RTWLogDataTypeConvert[] = {
        { 1, SS_DOUBLE, SS_INT16, 32, 1, 1, 1.0, -1, 0.0 }
      };

      static RTWLogSignalInfo rt_LoggedOutputSignalInfo[] = {
        {
          1,
          rt_LoggedOutputWidths,
          rt_LoggedOutputNumDimensions,
          rt_LoggedOutputDimensions,
          rt_LoggedOutputIsVarDims,
          rt_LoggedCurrentSignalDimensions,
          rt_LoggedCurrentSignalDimensionsSize,
          rt_LoggedOutputDataTypeIds,
          rt_LoggedOutputComplexSignals,
          (NULL),

          { rt_LoggedOutputLabels },
          (NULL),
          (NULL),
          (NULL),

          { rt_LoggedOutputBlockNames },

          { (NULL) },
          (NULL),
          rt_RTWLogDataTypeConvert
        }
      };

      rtliSetLogYSignalInfo(Discrete_PID_Controller_M->rtwLogInfo,
                            rt_LoggedOutputSignalInfo);

      /* set currSigDims field */
      rt_LoggedCurrentSignalDimensions[0] = &rt_LoggedOutputWidths[0];
    }

    rtliSetLogY(Discrete_PID_Controller_M->rtwLogInfo, "yout");
  }

  Discrete_PID_Controller_M->solverInfoPtr =
    (&Discrete_PID_Controller_M->solverInfo);
  Discrete_PID_Controller_M->Timing.stepSize = (0.1);
  rtsiSetFixedStepSize(&Discrete_PID_Controller_M->solverInfo, 0.1);
  rtsiSetSolverMode(&Discrete_PID_Controller_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  Discrete_PID_Controller_M->ModelData.blockIO = ((void *)
    &Discrete_PID_Controller_B);
  (void) memset(((void *) &Discrete_PID_Controller_B), 0,
                sizeof(BlockIO_Discrete_PID_Controller));

  /* parameters */
  Discrete_PID_Controller_M->ModelData.defaultParam = ((real_T *)
    &Discrete_PID_Controller_P);

  /* states (dwork) */
  Discrete_PID_Controller_M->Work.dwork = ((void *)
    &Discrete_PID_Controller_DWork);
  (void) memset((void *)&Discrete_PID_Controller_DWork, 0,
                sizeof(D_Work_Discrete_PID_Controller));

  /* external inputs */
  Discrete_PID_Controller_M->ModelData.inputs = (((void*)
    &Discrete_PID_Controller_U));
  Discrete_PID_Controller_U.errorf = 0;

  /* external outputs */
  Discrete_PID_Controller_M->ModelData.outputs = (&Discrete_PID_Controller_Y);
  Discrete_PID_Controller_Y.y = 0;

  /* Initialize Sizes */
  Discrete_PID_Controller_M->Sizes.numContStates = (0);/* Number of continuous states */
  Discrete_PID_Controller_M->Sizes.numY = (1);/* Number of model outputs */
  Discrete_PID_Controller_M->Sizes.numU = (1);/* Number of model inputs */
  Discrete_PID_Controller_M->Sizes.sysDirFeedThru = (1);/* The model is direct feedthrough */
  Discrete_PID_Controller_M->Sizes.numSampTimes = (1);/* Number of sample times */
  Discrete_PID_Controller_M->Sizes.numBlocks = (6);/* Number of blocks */
  Discrete_PID_Controller_M->Sizes.numBlockIO = (1);/* Number of block outputs */
  Discrete_PID_Controller_M->Sizes.numBlockPrms = (6);/* Sum of parameter "widths" */
  return Discrete_PID_Controller_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
