/*
 * Discrete_PID_Controller_data.c
 *
 * Code generation for model "Discrete_PID_Controller".
 *
 * Model version              : 1.85
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Sat Jun 08 20:59:35 2013
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Microchip->PIC18
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "Discrete_PID_Controller.h"
#include "Discrete_PID_Controller_private.h"

/* Block parameters (auto storage) */
Parameters_Discrete_PID_Control Discrete_PID_Controller_P = {
  32000,                               /* Computed Parameter: ProportionalGain_Gain
                                        * Referenced by: '<S1>/Proportional Gain'
                                        */
  0,                                   /* Computed Parameter: IntegralGain_Gain
                                        * Referenced by: '<S1>/Integral Gain'
                                        */
  0,                                   /* Computed Parameter: Integrator_IC
                                        * Referenced by: '<S1>/Integrator'
                                        */
  20000,                               /* Computed Parameter: Saturation_UpperSat
                                        * Referenced by: '<S1>/Saturation'
                                        */
  -20000,                              /* Computed Parameter: Saturation_LowerSat
                                        * Referenced by: '<S1>/Saturation'
                                        */
  13107                                /* Computed Parameter: Integrator_gainval
                                        * Referenced by: '<S1>/Integrator'
                                        */
};
