#include "Discrete.h"
#include "Discrete_private.h"

int16_T Kp = 2154;
int16_T Ki = 5781;
int16_T Kd = -32112;
D_Work DWork;
ExternalInputs U;
ExternalOutputs Y;
void Discrete_step(void)
{
  int16_T FilterCoefficient;
  FilterCoefficient = (int16_T)((int32_T)((int16_T)((int32_T)Kd * (int32_T)
    U.errorf >> 15) - DWork.Filter_DSTATE) * 133L >> 11);
  Y.y = ((((int16_T)((int32_T)Kp * (int32_T)U.errorf >> 15) >> 3) +
          DWork.Integrator_DSTATE) + (FilterCoefficient >> 3)) >> 10;
  DWork.Integrator_DSTATE += (int16_T)((int32_T)(int16_T)((int32_T)Ki * (int32_T)
    U.errorf >> 15) * 5243L >> 21);
  DWork.Filter_DSTATE += (int16_T)(5243L * (int32_T)FilterCoefficient >> 15);
}

void Discrete_initialize(void)
{
  (void) memset((void *)&DWork, 0,
                sizeof(D_Work));
  U.errorf = 0;
  Y.y = 0;
  DWork.Integrator_DSTATE = 18432;
}
