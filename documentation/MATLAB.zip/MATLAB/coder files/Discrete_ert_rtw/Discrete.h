#ifndef RTW_HEADER_Discrete_h_
#define RTW_HEADER_Discrete_h_
#ifndef Discrete_COMMON_INCLUDES_
# define Discrete_COMMON_INCLUDES_
#include <string.h>
#include "rtwtypes.h"
#endif

#include "Discrete_types.h"

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((void*) 0)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((void) 0)
#endif

typedef struct {
  int16_T Integrator_DSTATE;
  int16_T Filter_DSTATE;
} D_Work;

typedef struct {
  int16_T errorf;
} ExternalInputs;

typedef struct {
  int16_T y;
} ExternalOutputs;

extern D_Work DWork;
extern ExternalInputs U;
extern ExternalOutputs Y;
extern int16_T Kp;
extern int16_T Ki;
extern int16_T Kd;
extern void Discrete_initialize(void);
extern void Discrete_step(void);

#endif

