#ifndef RTW_HEADER_Discrete_types_h_
#define RTW_HEADER_Discrete_types_h_
#endif

